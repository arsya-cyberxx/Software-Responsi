/*******************************************************************************
* File Name: Tombol_3.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Tombol_3_H) /* Pins Tombol_3_H */
#define CY_PINS_Tombol_3_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Tombol_3_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Tombol_3__PORT == 15 && ((Tombol_3__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Tombol_3_Write(uint8 value);
void    Tombol_3_SetDriveMode(uint8 mode);
uint8   Tombol_3_ReadDataReg(void);
uint8   Tombol_3_Read(void);
void    Tombol_3_SetInterruptMode(uint16 position, uint16 mode);
uint8   Tombol_3_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Tombol_3_SetDriveMode() function.
     *  @{
     */
        #define Tombol_3_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Tombol_3_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Tombol_3_DM_RES_UP          PIN_DM_RES_UP
        #define Tombol_3_DM_RES_DWN         PIN_DM_RES_DWN
        #define Tombol_3_DM_OD_LO           PIN_DM_OD_LO
        #define Tombol_3_DM_OD_HI           PIN_DM_OD_HI
        #define Tombol_3_DM_STRONG          PIN_DM_STRONG
        #define Tombol_3_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Tombol_3_MASK               Tombol_3__MASK
#define Tombol_3_SHIFT              Tombol_3__SHIFT
#define Tombol_3_WIDTH              1u

/* Interrupt constants */
#if defined(Tombol_3__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Tombol_3_SetInterruptMode() function.
     *  @{
     */
        #define Tombol_3_INTR_NONE      (uint16)(0x0000u)
        #define Tombol_3_INTR_RISING    (uint16)(0x0001u)
        #define Tombol_3_INTR_FALLING   (uint16)(0x0002u)
        #define Tombol_3_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Tombol_3_INTR_MASK      (0x01u) 
#endif /* (Tombol_3__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Tombol_3_PS                     (* (reg8 *) Tombol_3__PS)
/* Data Register */
#define Tombol_3_DR                     (* (reg8 *) Tombol_3__DR)
/* Port Number */
#define Tombol_3_PRT_NUM                (* (reg8 *) Tombol_3__PRT) 
/* Connect to Analog Globals */                                                  
#define Tombol_3_AG                     (* (reg8 *) Tombol_3__AG)                       
/* Analog MUX bux enable */
#define Tombol_3_AMUX                   (* (reg8 *) Tombol_3__AMUX) 
/* Bidirectional Enable */                                                        
#define Tombol_3_BIE                    (* (reg8 *) Tombol_3__BIE)
/* Bit-mask for Aliased Register Access */
#define Tombol_3_BIT_MASK               (* (reg8 *) Tombol_3__BIT_MASK)
/* Bypass Enable */
#define Tombol_3_BYP                    (* (reg8 *) Tombol_3__BYP)
/* Port wide control signals */                                                   
#define Tombol_3_CTL                    (* (reg8 *) Tombol_3__CTL)
/* Drive Modes */
#define Tombol_3_DM0                    (* (reg8 *) Tombol_3__DM0) 
#define Tombol_3_DM1                    (* (reg8 *) Tombol_3__DM1)
#define Tombol_3_DM2                    (* (reg8 *) Tombol_3__DM2) 
/* Input Buffer Disable Override */
#define Tombol_3_INP_DIS                (* (reg8 *) Tombol_3__INP_DIS)
/* LCD Common or Segment Drive */
#define Tombol_3_LCD_COM_SEG            (* (reg8 *) Tombol_3__LCD_COM_SEG)
/* Enable Segment LCD */
#define Tombol_3_LCD_EN                 (* (reg8 *) Tombol_3__LCD_EN)
/* Slew Rate Control */
#define Tombol_3_SLW                    (* (reg8 *) Tombol_3__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Tombol_3_PRTDSI__CAPS_SEL       (* (reg8 *) Tombol_3__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Tombol_3_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Tombol_3__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Tombol_3_PRTDSI__OE_SEL0        (* (reg8 *) Tombol_3__PRTDSI__OE_SEL0) 
#define Tombol_3_PRTDSI__OE_SEL1        (* (reg8 *) Tombol_3__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Tombol_3_PRTDSI__OUT_SEL0       (* (reg8 *) Tombol_3__PRTDSI__OUT_SEL0) 
#define Tombol_3_PRTDSI__OUT_SEL1       (* (reg8 *) Tombol_3__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Tombol_3_PRTDSI__SYNC_OUT       (* (reg8 *) Tombol_3__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Tombol_3__SIO_CFG)
    #define Tombol_3_SIO_HYST_EN        (* (reg8 *) Tombol_3__SIO_HYST_EN)
    #define Tombol_3_SIO_REG_HIFREQ     (* (reg8 *) Tombol_3__SIO_REG_HIFREQ)
    #define Tombol_3_SIO_CFG            (* (reg8 *) Tombol_3__SIO_CFG)
    #define Tombol_3_SIO_DIFF           (* (reg8 *) Tombol_3__SIO_DIFF)
#endif /* (Tombol_3__SIO_CFG) */

/* Interrupt Registers */
#if defined(Tombol_3__INTSTAT)
    #define Tombol_3_INTSTAT            (* (reg8 *) Tombol_3__INTSTAT)
    #define Tombol_3_SNAP               (* (reg8 *) Tombol_3__SNAP)
    
	#define Tombol_3_0_INTTYPE_REG 		(* (reg8 *) Tombol_3__0__INTTYPE)
#endif /* (Tombol_3__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Tombol_3_H */


/* [] END OF FILE */
