/*******************************************************************************
* File Name: Enter.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Enter_H) /* Pins Enter_H */
#define CY_PINS_Enter_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Enter_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Enter__PORT == 15 && ((Enter__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Enter_Write(uint8 value);
void    Enter_SetDriveMode(uint8 mode);
uint8   Enter_ReadDataReg(void);
uint8   Enter_Read(void);
void    Enter_SetInterruptMode(uint16 position, uint16 mode);
uint8   Enter_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Enter_SetDriveMode() function.
     *  @{
     */
        #define Enter_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Enter_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Enter_DM_RES_UP          PIN_DM_RES_UP
        #define Enter_DM_RES_DWN         PIN_DM_RES_DWN
        #define Enter_DM_OD_LO           PIN_DM_OD_LO
        #define Enter_DM_OD_HI           PIN_DM_OD_HI
        #define Enter_DM_STRONG          PIN_DM_STRONG
        #define Enter_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Enter_MASK               Enter__MASK
#define Enter_SHIFT              Enter__SHIFT
#define Enter_WIDTH              1u

/* Interrupt constants */
#if defined(Enter__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Enter_SetInterruptMode() function.
     *  @{
     */
        #define Enter_INTR_NONE      (uint16)(0x0000u)
        #define Enter_INTR_RISING    (uint16)(0x0001u)
        #define Enter_INTR_FALLING   (uint16)(0x0002u)
        #define Enter_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Enter_INTR_MASK      (0x01u) 
#endif /* (Enter__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Enter_PS                     (* (reg8 *) Enter__PS)
/* Data Register */
#define Enter_DR                     (* (reg8 *) Enter__DR)
/* Port Number */
#define Enter_PRT_NUM                (* (reg8 *) Enter__PRT) 
/* Connect to Analog Globals */                                                  
#define Enter_AG                     (* (reg8 *) Enter__AG)                       
/* Analog MUX bux enable */
#define Enter_AMUX                   (* (reg8 *) Enter__AMUX) 
/* Bidirectional Enable */                                                        
#define Enter_BIE                    (* (reg8 *) Enter__BIE)
/* Bit-mask for Aliased Register Access */
#define Enter_BIT_MASK               (* (reg8 *) Enter__BIT_MASK)
/* Bypass Enable */
#define Enter_BYP                    (* (reg8 *) Enter__BYP)
/* Port wide control signals */                                                   
#define Enter_CTL                    (* (reg8 *) Enter__CTL)
/* Drive Modes */
#define Enter_DM0                    (* (reg8 *) Enter__DM0) 
#define Enter_DM1                    (* (reg8 *) Enter__DM1)
#define Enter_DM2                    (* (reg8 *) Enter__DM2) 
/* Input Buffer Disable Override */
#define Enter_INP_DIS                (* (reg8 *) Enter__INP_DIS)
/* LCD Common or Segment Drive */
#define Enter_LCD_COM_SEG            (* (reg8 *) Enter__LCD_COM_SEG)
/* Enable Segment LCD */
#define Enter_LCD_EN                 (* (reg8 *) Enter__LCD_EN)
/* Slew Rate Control */
#define Enter_SLW                    (* (reg8 *) Enter__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Enter_PRTDSI__CAPS_SEL       (* (reg8 *) Enter__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Enter_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Enter__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Enter_PRTDSI__OE_SEL0        (* (reg8 *) Enter__PRTDSI__OE_SEL0) 
#define Enter_PRTDSI__OE_SEL1        (* (reg8 *) Enter__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Enter_PRTDSI__OUT_SEL0       (* (reg8 *) Enter__PRTDSI__OUT_SEL0) 
#define Enter_PRTDSI__OUT_SEL1       (* (reg8 *) Enter__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Enter_PRTDSI__SYNC_OUT       (* (reg8 *) Enter__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Enter__SIO_CFG)
    #define Enter_SIO_HYST_EN        (* (reg8 *) Enter__SIO_HYST_EN)
    #define Enter_SIO_REG_HIFREQ     (* (reg8 *) Enter__SIO_REG_HIFREQ)
    #define Enter_SIO_CFG            (* (reg8 *) Enter__SIO_CFG)
    #define Enter_SIO_DIFF           (* (reg8 *) Enter__SIO_DIFF)
#endif /* (Enter__SIO_CFG) */

/* Interrupt Registers */
#if defined(Enter__INTSTAT)
    #define Enter_INTSTAT            (* (reg8 *) Enter__INTSTAT)
    #define Enter_SNAP               (* (reg8 *) Enter__SNAP)
    
	#define Enter_0_INTTYPE_REG 		(* (reg8 *) Enter__0__INTTYPE)
#endif /* (Enter__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Enter_H */


/* [] END OF FILE */
