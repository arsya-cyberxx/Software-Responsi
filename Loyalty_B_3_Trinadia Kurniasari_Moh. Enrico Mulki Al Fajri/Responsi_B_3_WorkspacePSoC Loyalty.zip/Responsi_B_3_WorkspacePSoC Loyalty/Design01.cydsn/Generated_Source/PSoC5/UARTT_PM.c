/*******************************************************************************
* File Name: UARTT_PM.c
* Version 2.50
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "UARTT.h"


/***************************************
* Local data allocation
***************************************/

static UARTT_BACKUP_STRUCT  UARTT_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: UARTT_SaveConfig
********************************************************************************
*
* Summary:
*  This function saves the component nonretention control register.
*  Does not save the FIFO which is a set of nonretention registers.
*  This function is called by the UARTT_Sleep() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UARTT_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UARTT_SaveConfig(void)
{
    #if(UARTT_CONTROL_REG_REMOVED == 0u)
        UARTT_backup.cr = UARTT_CONTROL_REG;
    #endif /* End UARTT_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: UARTT_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the nonretention control register except FIFO.
*  Does not restore the FIFO which is a set of nonretention registers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UARTT_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
* Notes:
*  If this function is called without calling UARTT_SaveConfig() 
*  first, the data loaded may be incorrect.
*
*******************************************************************************/
void UARTT_RestoreConfig(void)
{
    #if(UARTT_CONTROL_REG_REMOVED == 0u)
        UARTT_CONTROL_REG = UARTT_backup.cr;
    #endif /* End UARTT_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: UARTT_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred API to prepare the component for sleep. 
*  The UARTT_Sleep() API saves the current component state. Then it
*  calls the UARTT_Stop() function and calls 
*  UARTT_SaveConfig() to save the hardware configuration.
*  Call the UARTT_Sleep() function before calling the CyPmSleep() 
*  or the CyPmHibernate() function. 
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UARTT_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UARTT_Sleep(void)
{
    #if(UARTT_RX_ENABLED || UARTT_HD_ENABLED)
        if((UARTT_RXSTATUS_ACTL_REG  & UARTT_INT_ENABLE) != 0u)
        {
            UARTT_backup.enableState = 1u;
        }
        else
        {
            UARTT_backup.enableState = 0u;
        }
    #else
        if((UARTT_TXSTATUS_ACTL_REG  & UARTT_INT_ENABLE) !=0u)
        {
            UARTT_backup.enableState = 1u;
        }
        else
        {
            UARTT_backup.enableState = 0u;
        }
    #endif /* End UARTT_RX_ENABLED || UARTT_HD_ENABLED*/

    UARTT_Stop();
    UARTT_SaveConfig();
}


/*******************************************************************************
* Function Name: UARTT_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred API to restore the component to the state when 
*  UARTT_Sleep() was called. The UARTT_Wakeup() function
*  calls the UARTT_RestoreConfig() function to restore the 
*  configuration. If the component was enabled before the 
*  UARTT_Sleep() function was called, the UARTT_Wakeup()
*  function will also re-enable the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UARTT_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UARTT_Wakeup(void)
{
    UARTT_RestoreConfig();
    #if( (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) )
        UARTT_ClearRxBuffer();
    #endif /* End (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) */
    #if(UARTT_TX_ENABLED || UARTT_HD_ENABLED)
        UARTT_ClearTxBuffer();
    #endif /* End UARTT_TX_ENABLED || UARTT_HD_ENABLED */

    if(UARTT_backup.enableState != 0u)
    {
        UARTT_Enable();
    }
}


/* [] END OF FILE */
