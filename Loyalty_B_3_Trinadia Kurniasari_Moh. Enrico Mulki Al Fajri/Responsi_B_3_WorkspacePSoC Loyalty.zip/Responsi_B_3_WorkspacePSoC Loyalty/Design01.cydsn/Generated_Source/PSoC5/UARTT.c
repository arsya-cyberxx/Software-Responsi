/*******************************************************************************
* File Name: UARTT.c
* Version 2.50
*
* Description:
*  This file provides all API functionality of the UART component
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "UARTT.h"
#if (UARTT_INTERNAL_CLOCK_USED)
    #include "UARTT_IntClock.h"
#endif /* End UARTT_INTERNAL_CLOCK_USED */


/***************************************
* Global data allocation
***************************************/

uint8 UARTT_initVar = 0u;

#if (UARTT_TX_INTERRUPT_ENABLED && UARTT_TX_ENABLED)
    volatile uint8 UARTT_txBuffer[UARTT_TX_BUFFER_SIZE];
    volatile uint8 UARTT_txBufferRead = 0u;
    uint8 UARTT_txBufferWrite = 0u;
#endif /* (UARTT_TX_INTERRUPT_ENABLED && UARTT_TX_ENABLED) */

#if (UARTT_RX_INTERRUPT_ENABLED && (UARTT_RX_ENABLED || UARTT_HD_ENABLED))
    uint8 UARTT_errorStatus = 0u;
    volatile uint8 UARTT_rxBuffer[UARTT_RX_BUFFER_SIZE];
    volatile uint8 UARTT_rxBufferRead  = 0u;
    volatile uint8 UARTT_rxBufferWrite = 0u;
    volatile uint8 UARTT_rxBufferLoopDetect = 0u;
    volatile uint8 UARTT_rxBufferOverflow   = 0u;
    #if (UARTT_RXHW_ADDRESS_ENABLED)
        volatile uint8 UARTT_rxAddressMode = UARTT_RX_ADDRESS_MODE;
        volatile uint8 UARTT_rxAddressDetected = 0u;
    #endif /* (UARTT_RXHW_ADDRESS_ENABLED) */
#endif /* (UARTT_RX_INTERRUPT_ENABLED && (UARTT_RX_ENABLED || UARTT_HD_ENABLED)) */


/*******************************************************************************
* Function Name: UARTT_Start
********************************************************************************
*
* Summary:
*  This is the preferred method to begin component operation.
*  UARTT_Start() sets the initVar variable, calls the
*  UARTT_Init() function, and then calls the
*  UARTT_Enable() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  The UARTT_intiVar variable is used to indicate initial
*  configuration of this component. The variable is initialized to zero (0u)
*  and set to one (1u) the first time UARTT_Start() is called. This
*  allows for component initialization without re-initialization in all
*  subsequent calls to the UARTT_Start() routine.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UARTT_Start(void) 
{
    /* If not initialized then initialize all required hardware and software */
    if(UARTT_initVar == 0u)
    {
        UARTT_Init();
        UARTT_initVar = 1u;
    }

    UARTT_Enable();
}


/*******************************************************************************
* Function Name: UARTT_Init
********************************************************************************
*
* Summary:
*  Initializes or restores the component according to the customizer Configure
*  dialog settings. It is not necessary to call UARTT_Init() because
*  the UARTT_Start() API calls this function and is the preferred
*  method to begin component operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void UARTT_Init(void) 
{
    #if(UARTT_RX_ENABLED || UARTT_HD_ENABLED)

        #if (UARTT_RX_INTERRUPT_ENABLED)
            /* Set RX interrupt vector and priority */
            (void) CyIntSetVector(UARTT_RX_VECT_NUM, &UARTT_RXISR);
            CyIntSetPriority(UARTT_RX_VECT_NUM, UARTT_RX_PRIOR_NUM);
            UARTT_errorStatus = 0u;
        #endif /* (UARTT_RX_INTERRUPT_ENABLED) */

        #if (UARTT_RXHW_ADDRESS_ENABLED)
            UARTT_SetRxAddressMode(UARTT_RX_ADDRESS_MODE);
            UARTT_SetRxAddress1(UARTT_RX_HW_ADDRESS1);
            UARTT_SetRxAddress2(UARTT_RX_HW_ADDRESS2);
        #endif /* End UARTT_RXHW_ADDRESS_ENABLED */

        /* Init Count7 period */
        UARTT_RXBITCTR_PERIOD_REG = UARTT_RXBITCTR_INIT;
        /* Configure the Initial RX interrupt mask */
        UARTT_RXSTATUS_MASK_REG  = UARTT_INIT_RX_INTERRUPTS_MASK;
    #endif /* End UARTT_RX_ENABLED || UARTT_HD_ENABLED*/

    #if(UARTT_TX_ENABLED)
        #if (UARTT_TX_INTERRUPT_ENABLED)
            /* Set TX interrupt vector and priority */
            (void) CyIntSetVector(UARTT_TX_VECT_NUM, &UARTT_TXISR);
            CyIntSetPriority(UARTT_TX_VECT_NUM, UARTT_TX_PRIOR_NUM);
        #endif /* (UARTT_TX_INTERRUPT_ENABLED) */

        /* Write Counter Value for TX Bit Clk Generator*/
        #if (UARTT_TXCLKGEN_DP)
            UARTT_TXBITCLKGEN_CTR_REG = UARTT_BIT_CENTER;
            UARTT_TXBITCLKTX_COMPLETE_REG = ((UARTT_NUMBER_OF_DATA_BITS +
                        UARTT_NUMBER_OF_START_BIT) * UARTT_OVER_SAMPLE_COUNT) - 1u;
        #else
            UARTT_TXBITCTR_PERIOD_REG = ((UARTT_NUMBER_OF_DATA_BITS +
                        UARTT_NUMBER_OF_START_BIT) * UARTT_OVER_SAMPLE_8) - 1u;
        #endif /* End UARTT_TXCLKGEN_DP */

        /* Configure the Initial TX interrupt mask */
        #if (UARTT_TX_INTERRUPT_ENABLED)
            UARTT_TXSTATUS_MASK_REG = UARTT_TX_STS_FIFO_EMPTY;
        #else
            UARTT_TXSTATUS_MASK_REG = UARTT_INIT_TX_INTERRUPTS_MASK;
        #endif /*End UARTT_TX_INTERRUPT_ENABLED*/

    #endif /* End UARTT_TX_ENABLED */

    #if(UARTT_PARITY_TYPE_SW)  /* Write Parity to Control Register */
        UARTT_WriteControlRegister( \
            (UARTT_ReadControlRegister() & (uint8)~UARTT_CTRL_PARITY_TYPE_MASK) | \
            (uint8)(UARTT_PARITY_TYPE << UARTT_CTRL_PARITY_TYPE0_SHIFT) );
    #endif /* End UARTT_PARITY_TYPE_SW */
}


/*******************************************************************************
* Function Name: UARTT_Enable
********************************************************************************
*
* Summary:
*  Activates the hardware and begins component operation. It is not necessary
*  to call UARTT_Enable() because the UARTT_Start() API
*  calls this function, which is the preferred method to begin component
*  operation.

* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UARTT_rxAddressDetected - set to initial state (0).
*
*******************************************************************************/
void UARTT_Enable(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    #if (UARTT_RX_ENABLED || UARTT_HD_ENABLED)
        /* RX Counter (Count7) Enable */
        UARTT_RXBITCTR_CONTROL_REG |= UARTT_CNTR_ENABLE;

        /* Enable the RX Interrupt */
        UARTT_RXSTATUS_ACTL_REG  |= UARTT_INT_ENABLE;

        #if (UARTT_RX_INTERRUPT_ENABLED)
            UARTT_EnableRxInt();

            #if (UARTT_RXHW_ADDRESS_ENABLED)
                UARTT_rxAddressDetected = 0u;
            #endif /* (UARTT_RXHW_ADDRESS_ENABLED) */
        #endif /* (UARTT_RX_INTERRUPT_ENABLED) */
    #endif /* (UARTT_RX_ENABLED || UARTT_HD_ENABLED) */

    #if(UARTT_TX_ENABLED)
        /* TX Counter (DP/Count7) Enable */
        #if(!UARTT_TXCLKGEN_DP)
            UARTT_TXBITCTR_CONTROL_REG |= UARTT_CNTR_ENABLE;
        #endif /* End UARTT_TXCLKGEN_DP */

        /* Enable the TX Interrupt */
        UARTT_TXSTATUS_ACTL_REG |= UARTT_INT_ENABLE;
        #if (UARTT_TX_INTERRUPT_ENABLED)
            UARTT_ClearPendingTxInt(); /* Clear history of TX_NOT_EMPTY */
            UARTT_EnableTxInt();
        #endif /* (UARTT_TX_INTERRUPT_ENABLED) */
     #endif /* (UARTT_TX_INTERRUPT_ENABLED) */

    #if (UARTT_INTERNAL_CLOCK_USED)
        UARTT_IntClock_Start();  /* Enable the clock */
    #endif /* (UARTT_INTERNAL_CLOCK_USED) */

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: UARTT_Stop
********************************************************************************
*
* Summary:
*  Disables the UART operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void UARTT_Stop(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    /* Write Bit Counter Disable */
    #if (UARTT_RX_ENABLED || UARTT_HD_ENABLED)
        UARTT_RXBITCTR_CONTROL_REG &= (uint8) ~UARTT_CNTR_ENABLE;
    #endif /* (UARTT_RX_ENABLED || UARTT_HD_ENABLED) */

    #if (UARTT_TX_ENABLED)
        #if(!UARTT_TXCLKGEN_DP)
            UARTT_TXBITCTR_CONTROL_REG &= (uint8) ~UARTT_CNTR_ENABLE;
        #endif /* (!UARTT_TXCLKGEN_DP) */
    #endif /* (UARTT_TX_ENABLED) */

    #if (UARTT_INTERNAL_CLOCK_USED)
        UARTT_IntClock_Stop();   /* Disable the clock */
    #endif /* (UARTT_INTERNAL_CLOCK_USED) */

    /* Disable internal interrupt component */
    #if (UARTT_RX_ENABLED || UARTT_HD_ENABLED)
        UARTT_RXSTATUS_ACTL_REG  &= (uint8) ~UARTT_INT_ENABLE;

        #if (UARTT_RX_INTERRUPT_ENABLED)
            UARTT_DisableRxInt();
        #endif /* (UARTT_RX_INTERRUPT_ENABLED) */
    #endif /* (UARTT_RX_ENABLED || UARTT_HD_ENABLED) */

    #if (UARTT_TX_ENABLED)
        UARTT_TXSTATUS_ACTL_REG &= (uint8) ~UARTT_INT_ENABLE;

        #if (UARTT_TX_INTERRUPT_ENABLED)
            UARTT_DisableTxInt();
        #endif /* (UARTT_TX_INTERRUPT_ENABLED) */
    #endif /* (UARTT_TX_ENABLED) */

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: UARTT_ReadControlRegister
********************************************************************************
*
* Summary:
*  Returns the current value of the control register.
*
* Parameters:
*  None.
*
* Return:
*  Contents of the control register.
*
*******************************************************************************/
uint8 UARTT_ReadControlRegister(void) 
{
    #if (UARTT_CONTROL_REG_REMOVED)
        return(0u);
    #else
        return(UARTT_CONTROL_REG);
    #endif /* (UARTT_CONTROL_REG_REMOVED) */
}


/*******************************************************************************
* Function Name: UARTT_WriteControlRegister
********************************************************************************
*
* Summary:
*  Writes an 8-bit value into the control register
*
* Parameters:
*  control:  control register value
*
* Return:
*  None.
*
*******************************************************************************/
void  UARTT_WriteControlRegister(uint8 control) 
{
    #if (UARTT_CONTROL_REG_REMOVED)
        if(0u != control)
        {
            /* Suppress compiler warning */
        }
    #else
       UARTT_CONTROL_REG = control;
    #endif /* (UARTT_CONTROL_REG_REMOVED) */
}


#if(UARTT_RX_ENABLED || UARTT_HD_ENABLED)
    /*******************************************************************************
    * Function Name: UARTT_SetRxInterruptMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the RX interrupt sources enabled.
    *
    * Parameters:
    *  IntSrc:  Bit field containing the RX interrupts to enable. Based on the 
    *  bit-field arrangement of the status register. This value must be a 
    *  combination of status register bit-masks shown below:
    *      UARTT_RX_STS_FIFO_NOTEMPTY    Interrupt on byte received.
    *      UARTT_RX_STS_PAR_ERROR        Interrupt on parity error.
    *      UARTT_RX_STS_STOP_ERROR       Interrupt on stop error.
    *      UARTT_RX_STS_BREAK            Interrupt on break.
    *      UARTT_RX_STS_OVERRUN          Interrupt on overrun error.
    *      UARTT_RX_STS_ADDR_MATCH       Interrupt on address match.
    *      UARTT_RX_STS_MRKSPC           Interrupt on address detect.
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Enables the output of specific status bits to the interrupt controller
    *
    *******************************************************************************/
    void UARTT_SetRxInterruptMode(uint8 intSrc) 
    {
        UARTT_RXSTATUS_MASK_REG  = intSrc;
    }


    /*******************************************************************************
    * Function Name: UARTT_ReadRxData
    ********************************************************************************
    *
    * Summary:
    *  Returns the next byte of received data. This function returns data without
    *  checking the status. You must check the status separately.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Received data from RX register
    *
    * Global Variables:
    *  UARTT_rxBuffer - RAM buffer pointer for save received data.
    *  UARTT_rxBufferWrite - cyclic index for write to rxBuffer,
    *     checked to identify new data.
    *  UARTT_rxBufferRead - cyclic index for read from rxBuffer,
    *     incremented after each byte has been read from buffer.
    *  UARTT_rxBufferLoopDetect - cleared if loop condition was detected
    *     in RX ISR.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint8 UARTT_ReadRxData(void) 
    {
        uint8 rxData;

    #if (UARTT_RX_INTERRUPT_ENABLED)

        uint8 locRxBufferRead;
        uint8 locRxBufferWrite;

        /* Protect variables that could change on interrupt */
        UARTT_DisableRxInt();

        locRxBufferRead  = UARTT_rxBufferRead;
        locRxBufferWrite = UARTT_rxBufferWrite;

        if( (UARTT_rxBufferLoopDetect != 0u) || (locRxBufferRead != locRxBufferWrite) )
        {
            rxData = UARTT_rxBuffer[locRxBufferRead];
            locRxBufferRead++;

            if(locRxBufferRead >= UARTT_RX_BUFFER_SIZE)
            {
                locRxBufferRead = 0u;
            }
            /* Update the real pointer */
            UARTT_rxBufferRead = locRxBufferRead;

            if(UARTT_rxBufferLoopDetect != 0u)
            {
                UARTT_rxBufferLoopDetect = 0u;
                #if ((UARTT_RX_INTERRUPT_ENABLED) && (UARTT_FLOW_CONTROL != 0u))
                    /* When Hardware Flow Control selected - return RX mask */
                    #if( UARTT_HD_ENABLED )
                        if((UARTT_CONTROL_REG & UARTT_CTRL_HD_SEND) == 0u)
                        {   /* In Half duplex mode return RX mask only in RX
                            *  configuration set, otherwise
                            *  mask will be returned in LoadRxConfig() API.
                            */
                            UARTT_RXSTATUS_MASK_REG  |= UARTT_RX_STS_FIFO_NOTEMPTY;
                        }
                    #else
                        UARTT_RXSTATUS_MASK_REG  |= UARTT_RX_STS_FIFO_NOTEMPTY;
                    #endif /* end UARTT_HD_ENABLED */
                #endif /* ((UARTT_RX_INTERRUPT_ENABLED) && (UARTT_FLOW_CONTROL != 0u)) */
            }
        }
        else
        {   /* Needs to check status for RX_STS_FIFO_NOTEMPTY bit */
            rxData = UARTT_RXDATA_REG;
        }

        UARTT_EnableRxInt();

    #else

        /* Needs to check status for RX_STS_FIFO_NOTEMPTY bit */
        rxData = UARTT_RXDATA_REG;

    #endif /* (UARTT_RX_INTERRUPT_ENABLED) */

        return(rxData);
    }


    /*******************************************************************************
    * Function Name: UARTT_ReadRxStatus
    ********************************************************************************
    *
    * Summary:
    *  Returns the current state of the receiver status register and the software
    *  buffer overflow status.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Current state of the status register.
    *
    * Side Effect:
    *  All status register bits are clear-on-read except
    *  UARTT_RX_STS_FIFO_NOTEMPTY.
    *  UARTT_RX_STS_FIFO_NOTEMPTY clears immediately after RX data
    *  register read.
    *
    * Global Variables:
    *  UARTT_rxBufferOverflow - used to indicate overload condition.
    *   It set to one in RX interrupt when there isn't free space in
    *   UARTT_rxBufferRead to write new data. This condition returned
    *   and cleared to zero by this API as an
    *   UARTT_RX_STS_SOFT_BUFF_OVER bit along with RX Status register
    *   bits.
    *
    *******************************************************************************/
    uint8 UARTT_ReadRxStatus(void) 
    {
        uint8 status;

        status = UARTT_RXSTATUS_REG & UARTT_RX_HW_MASK;

    #if (UARTT_RX_INTERRUPT_ENABLED)
        if(UARTT_rxBufferOverflow != 0u)
        {
            status |= UARTT_RX_STS_SOFT_BUFF_OVER;
            UARTT_rxBufferOverflow = 0u;
        }
    #endif /* (UARTT_RX_INTERRUPT_ENABLED) */

        return(status);
    }


    /*******************************************************************************
    * Function Name: UARTT_GetChar
    ********************************************************************************
    *
    * Summary:
    *  Returns the last received byte of data. UARTT_GetChar() is
    *  designed for ASCII characters and returns a uint8 where 1 to 255 are values
    *  for valid characters and 0 indicates an error occurred or no data is present.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Character read from UART RX buffer. ASCII characters from 1 to 255 are valid.
    *  A returned zero signifies an error condition or no data available.
    *
    * Global Variables:
    *  UARTT_rxBuffer - RAM buffer pointer for save received data.
    *  UARTT_rxBufferWrite - cyclic index for write to rxBuffer,
    *     checked to identify new data.
    *  UARTT_rxBufferRead - cyclic index for read from rxBuffer,
    *     incremented after each byte has been read from buffer.
    *  UARTT_rxBufferLoopDetect - cleared if loop condition was detected
    *     in RX ISR.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint8 UARTT_GetChar(void) 
    {
        uint8 rxData = 0u;
        uint8 rxStatus;

    #if (UARTT_RX_INTERRUPT_ENABLED)
        uint8 locRxBufferRead;
        uint8 locRxBufferWrite;

        /* Protect variables that could change on interrupt */
        UARTT_DisableRxInt();

        locRxBufferRead  = UARTT_rxBufferRead;
        locRxBufferWrite = UARTT_rxBufferWrite;

        if( (UARTT_rxBufferLoopDetect != 0u) || (locRxBufferRead != locRxBufferWrite) )
        {
            rxData = UARTT_rxBuffer[locRxBufferRead];
            locRxBufferRead++;
            if(locRxBufferRead >= UARTT_RX_BUFFER_SIZE)
            {
                locRxBufferRead = 0u;
            }
            /* Update the real pointer */
            UARTT_rxBufferRead = locRxBufferRead;

            if(UARTT_rxBufferLoopDetect != 0u)
            {
                UARTT_rxBufferLoopDetect = 0u;
                #if( (UARTT_RX_INTERRUPT_ENABLED) && (UARTT_FLOW_CONTROL != 0u) )
                    /* When Hardware Flow Control selected - return RX mask */
                    #if( UARTT_HD_ENABLED )
                        if((UARTT_CONTROL_REG & UARTT_CTRL_HD_SEND) == 0u)
                        {   /* In Half duplex mode return RX mask only if
                            *  RX configuration set, otherwise
                            *  mask will be returned in LoadRxConfig() API.
                            */
                            UARTT_RXSTATUS_MASK_REG |= UARTT_RX_STS_FIFO_NOTEMPTY;
                        }
                    #else
                        UARTT_RXSTATUS_MASK_REG |= UARTT_RX_STS_FIFO_NOTEMPTY;
                    #endif /* end UARTT_HD_ENABLED */
                #endif /* UARTT_RX_INTERRUPT_ENABLED and Hardware flow control*/
            }

        }
        else
        {   rxStatus = UARTT_RXSTATUS_REG;
            if((rxStatus & UARTT_RX_STS_FIFO_NOTEMPTY) != 0u)
            {   /* Read received data from FIFO */
                rxData = UARTT_RXDATA_REG;
                /*Check status on error*/
                if((rxStatus & (UARTT_RX_STS_BREAK | UARTT_RX_STS_PAR_ERROR |
                                UARTT_RX_STS_STOP_ERROR | UARTT_RX_STS_OVERRUN)) != 0u)
                {
                    rxData = 0u;
                }
            }
        }

        UARTT_EnableRxInt();

    #else

        rxStatus =UARTT_RXSTATUS_REG;
        if((rxStatus & UARTT_RX_STS_FIFO_NOTEMPTY) != 0u)
        {
            /* Read received data from FIFO */
            rxData = UARTT_RXDATA_REG;

            /*Check status on error*/
            if((rxStatus & (UARTT_RX_STS_BREAK | UARTT_RX_STS_PAR_ERROR |
                            UARTT_RX_STS_STOP_ERROR | UARTT_RX_STS_OVERRUN)) != 0u)
            {
                rxData = 0u;
            }
        }
    #endif /* (UARTT_RX_INTERRUPT_ENABLED) */

        return(rxData);
    }


    /*******************************************************************************
    * Function Name: UARTT_GetByte
    ********************************************************************************
    *
    * Summary:
    *  Reads UART RX buffer immediately, returns received character and error
    *  condition.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  MSB contains status and LSB contains UART RX data. If the MSB is nonzero,
    *  an error has occurred.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint16 UARTT_GetByte(void) 
    {
        
    #if (UARTT_RX_INTERRUPT_ENABLED)
        uint16 locErrorStatus;
        /* Protect variables that could change on interrupt */
        UARTT_DisableRxInt();
        locErrorStatus = (uint16)UARTT_errorStatus;
        UARTT_errorStatus = 0u;
        UARTT_EnableRxInt();
        return ( (uint16)(locErrorStatus << 8u) | UARTT_ReadRxData() );
    #else
        return ( ((uint16)UARTT_ReadRxStatus() << 8u) | UARTT_ReadRxData() );
    #endif /* UARTT_RX_INTERRUPT_ENABLED */
        
    }


    /*******************************************************************************
    * Function Name: UARTT_GetRxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of received bytes available in the RX buffer.
    *  * RX software buffer is disabled (RX Buffer Size parameter is equal to 4): 
    *    returns 0 for empty RX FIFO or 1 for not empty RX FIFO.
    *  * RX software buffer is enabled: returns the number of bytes available in 
    *    the RX software buffer. Bytes available in the RX FIFO do not take to 
    *    account.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  uint8: Number of bytes in the RX buffer. 
    *    Return value type depends on RX Buffer Size parameter.
    *
    * Global Variables:
    *  UARTT_rxBufferWrite - used to calculate left bytes.
    *  UARTT_rxBufferRead - used to calculate left bytes.
    *  UARTT_rxBufferLoopDetect - checked to decide left bytes amount.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to find out how full the RX Buffer is.
    *
    *******************************************************************************/
    uint8 UARTT_GetRxBufferSize(void)
                                                            
    {
        uint8 size;

    #if (UARTT_RX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt */
        UARTT_DisableRxInt();

        if(UARTT_rxBufferRead == UARTT_rxBufferWrite)
        {
            if(UARTT_rxBufferLoopDetect != 0u)
            {
                size = UARTT_RX_BUFFER_SIZE;
            }
            else
            {
                size = 0u;
            }
        }
        else if(UARTT_rxBufferRead < UARTT_rxBufferWrite)
        {
            size = (UARTT_rxBufferWrite - UARTT_rxBufferRead);
        }
        else
        {
            size = (UARTT_RX_BUFFER_SIZE - UARTT_rxBufferRead) + UARTT_rxBufferWrite;
        }

        UARTT_EnableRxInt();

    #else

        /* We can only know if there is data in the fifo. */
        size = ((UARTT_RXSTATUS_REG & UARTT_RX_STS_FIFO_NOTEMPTY) != 0u) ? 1u : 0u;

    #endif /* (UARTT_RX_INTERRUPT_ENABLED) */

        return(size);
    }


    /*******************************************************************************
    * Function Name: UARTT_ClearRxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clears the receiver memory buffer and hardware RX FIFO of all received data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTT_rxBufferWrite - cleared to zero.
    *  UARTT_rxBufferRead - cleared to zero.
    *  UARTT_rxBufferLoopDetect - cleared to zero.
    *  UARTT_rxBufferOverflow - cleared to zero.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Setting the pointers to zero makes the system believe there is no data to
    *  read and writing will resume at address 0 overwriting any data that may
    *  have remained in the RAM.
    *
    * Side Effects:
    *  Any received data not read from the RAM or FIFO buffer will be lost.
    *
    *******************************************************************************/
    void UARTT_ClearRxBuffer(void) 
    {
        uint8 enableInterrupts;

        /* Clear the HW FIFO */
        enableInterrupts = CyEnterCriticalSection();
        UARTT_RXDATA_AUX_CTL_REG |= (uint8)  UARTT_RX_FIFO_CLR;
        UARTT_RXDATA_AUX_CTL_REG &= (uint8) ~UARTT_RX_FIFO_CLR;
        CyExitCriticalSection(enableInterrupts);

    #if (UARTT_RX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        UARTT_DisableRxInt();

        UARTT_rxBufferRead = 0u;
        UARTT_rxBufferWrite = 0u;
        UARTT_rxBufferLoopDetect = 0u;
        UARTT_rxBufferOverflow = 0u;

        UARTT_EnableRxInt();

    #endif /* (UARTT_RX_INTERRUPT_ENABLED) */

    }


    /*******************************************************************************
    * Function Name: UARTT_SetRxAddressMode
    ********************************************************************************
    *
    * Summary:
    *  Sets the software controlled Addressing mode used by the RX portion of the
    *  UART.
    *
    * Parameters:
    *  addressMode: Enumerated value indicating the mode of RX addressing
    *  UARTT__B_UART__AM_SW_BYTE_BYTE -  Software Byte-by-Byte address
    *                                               detection
    *  UARTT__B_UART__AM_SW_DETECT_TO_BUFFER - Software Detect to Buffer
    *                                               address detection
    *  UARTT__B_UART__AM_HW_BYTE_BY_BYTE - Hardware Byte-by-Byte address
    *                                               detection
    *  UARTT__B_UART__AM_HW_DETECT_TO_BUFFER - Hardware Detect to Buffer
    *                                               address detection
    *  UARTT__B_UART__AM_NONE - No address detection
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTT_rxAddressMode - the parameter stored in this variable for
    *   the farther usage in RX ISR.
    *  UARTT_rxAddressDetected - set to initial state (0).
    *
    *******************************************************************************/
    void UARTT_SetRxAddressMode(uint8 addressMode)
                                                        
    {
        #if(UARTT_RXHW_ADDRESS_ENABLED)
            #if(UARTT_CONTROL_REG_REMOVED)
                if(0u != addressMode)
                {
                    /* Suppress compiler warning */
                }
            #else /* UARTT_CONTROL_REG_REMOVED */
                uint8 tmpCtrl;
                tmpCtrl = UARTT_CONTROL_REG & (uint8)~UARTT_CTRL_RXADDR_MODE_MASK;
                tmpCtrl |= (uint8)(addressMode << UARTT_CTRL_RXADDR_MODE0_SHIFT);
                UARTT_CONTROL_REG = tmpCtrl;

                #if(UARTT_RX_INTERRUPT_ENABLED && \
                   (UARTT_RXBUFFERSIZE > UARTT_FIFO_LENGTH) )
                    UARTT_rxAddressMode = addressMode;
                    UARTT_rxAddressDetected = 0u;
                #endif /* End UARTT_RXBUFFERSIZE > UARTT_FIFO_LENGTH*/
            #endif /* End UARTT_CONTROL_REG_REMOVED */
        #else /* UARTT_RXHW_ADDRESS_ENABLED */
            if(0u != addressMode)
            {
                /* Suppress compiler warning */
            }
        #endif /* End UARTT_RXHW_ADDRESS_ENABLED */
    }


    /*******************************************************************************
    * Function Name: UARTT_SetRxAddress1
    ********************************************************************************
    *
    * Summary:
    *  Sets the first of two hardware-detectable receiver addresses.
    *
    * Parameters:
    *  address: Address #1 for hardware address detection.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    void UARTT_SetRxAddress1(uint8 address) 
    {
        UARTT_RXADDRESS1_REG = address;
    }


    /*******************************************************************************
    * Function Name: UARTT_SetRxAddress2
    ********************************************************************************
    *
    * Summary:
    *  Sets the second of two hardware-detectable receiver addresses.
    *
    * Parameters:
    *  address: Address #2 for hardware address detection.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    void UARTT_SetRxAddress2(uint8 address) 
    {
        UARTT_RXADDRESS2_REG = address;
    }

#endif  /* UARTT_RX_ENABLED || UARTT_HD_ENABLED*/


#if( (UARTT_TX_ENABLED) || (UARTT_HD_ENABLED) )
    /*******************************************************************************
    * Function Name: UARTT_SetTxInterruptMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the TX interrupt sources to be enabled, but does not enable the
    *  interrupt.
    *
    * Parameters:
    *  intSrc: Bit field containing the TX interrupt sources to enable
    *   UARTT_TX_STS_COMPLETE        Interrupt on TX byte complete
    *   UARTT_TX_STS_FIFO_EMPTY      Interrupt when TX FIFO is empty
    *   UARTT_TX_STS_FIFO_FULL       Interrupt when TX FIFO is full
    *   UARTT_TX_STS_FIFO_NOT_FULL   Interrupt when TX FIFO is not full
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Enables the output of specific status bits to the interrupt controller
    *
    *******************************************************************************/
    void UARTT_SetTxInterruptMode(uint8 intSrc) 
    {
        UARTT_TXSTATUS_MASK_REG = intSrc;
    }


    /*******************************************************************************
    * Function Name: UARTT_WriteTxData
    ********************************************************************************
    *
    * Summary:
    *  Places a byte of data into the transmit buffer to be sent when the bus is
    *  available without checking the TX status register. You must check status
    *  separately.
    *
    * Parameters:
    *  txDataByte: data byte
    *
    * Return:
    * None.
    *
    * Global Variables:
    *  UARTT_txBuffer - RAM buffer pointer for save data for transmission
    *  UARTT_txBufferWrite - cyclic index for write to txBuffer,
    *    incremented after each byte saved to buffer.
    *  UARTT_txBufferRead - cyclic index for read from txBuffer,
    *    checked to identify the condition to write to FIFO directly or to TX buffer
    *  UARTT_initVar - checked to identify that the component has been
    *    initialized.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void UARTT_WriteTxData(uint8 txDataByte) 
    {
        /* If not Initialized then skip this function*/
        if(UARTT_initVar != 0u)
        {
        #if (UARTT_TX_INTERRUPT_ENABLED)

            /* Protect variables that could change on interrupt. */
            UARTT_DisableTxInt();

            if( (UARTT_txBufferRead == UARTT_txBufferWrite) &&
                ((UARTT_TXSTATUS_REG & UARTT_TX_STS_FIFO_FULL) == 0u) )
            {
                /* Add directly to the FIFO. */
                UARTT_TXDATA_REG = txDataByte;
            }
            else
            {
                if(UARTT_txBufferWrite >= UARTT_TX_BUFFER_SIZE)
                {
                    UARTT_txBufferWrite = 0u;
                }

                UARTT_txBuffer[UARTT_txBufferWrite] = txDataByte;

                /* Add to the software buffer. */
                UARTT_txBufferWrite++;
            }

            UARTT_EnableTxInt();

        #else

            /* Add directly to the FIFO. */
            UARTT_TXDATA_REG = txDataByte;

        #endif /*(UARTT_TX_INTERRUPT_ENABLED) */
        }
    }


    /*******************************************************************************
    * Function Name: UARTT_ReadTxStatus
    ********************************************************************************
    *
    * Summary:
    *  Reads the status register for the TX portion of the UART.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Contents of the status register
    *
    * Theory:
    *  This function reads the TX status register, which is cleared on read.
    *  It is up to the user to handle all bits in this return value accordingly,
    *  even if the bit was not enabled as an interrupt source the event happened
    *  and must be handled accordingly.
    *
    *******************************************************************************/
    uint8 UARTT_ReadTxStatus(void) 
    {
        return(UARTT_TXSTATUS_REG);
    }


    /*******************************************************************************
    * Function Name: UARTT_PutChar
    ********************************************************************************
    *
    * Summary:
    *  Puts a byte of data into the transmit buffer to be sent when the bus is
    *  available. This is a blocking API that waits until the TX buffer has room to
    *  hold the data.
    *
    * Parameters:
    *  txDataByte: Byte containing the data to transmit
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTT_txBuffer - RAM buffer pointer for save data for transmission
    *  UARTT_txBufferWrite - cyclic index for write to txBuffer,
    *     checked to identify free space in txBuffer and incremented after each byte
    *     saved to buffer.
    *  UARTT_txBufferRead - cyclic index for read from txBuffer,
    *     checked to identify free space in txBuffer.
    *  UARTT_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to transmit any byte of data in a single transfer
    *
    *******************************************************************************/
    void UARTT_PutChar(uint8 txDataByte) 
    {
    #if (UARTT_TX_INTERRUPT_ENABLED)
        /* The temporary output pointer is used since it takes two instructions
        *  to increment with a wrap, and we can't risk doing that with the real
        *  pointer and getting an interrupt in between instructions.
        */
        uint8 locTxBufferWrite;
        uint8 locTxBufferRead;

        do
        { /* Block if software buffer is full, so we don't overwrite. */

        #if ((UARTT_TX_BUFFER_SIZE > UARTT_MAX_BYTE_VALUE) && (CY_PSOC3))
            /* Disable TX interrupt to protect variables from modification */
            UARTT_DisableTxInt();
        #endif /* (UARTT_TX_BUFFER_SIZE > UARTT_MAX_BYTE_VALUE) && (CY_PSOC3) */

            locTxBufferWrite = UARTT_txBufferWrite;
            locTxBufferRead  = UARTT_txBufferRead;

        #if ((UARTT_TX_BUFFER_SIZE > UARTT_MAX_BYTE_VALUE) && (CY_PSOC3))
            /* Enable interrupt to continue transmission */
            UARTT_EnableTxInt();
        #endif /* (UARTT_TX_BUFFER_SIZE > UARTT_MAX_BYTE_VALUE) && (CY_PSOC3) */
        }
        while( (locTxBufferWrite < locTxBufferRead) ? (locTxBufferWrite == (locTxBufferRead - 1u)) :
                                ((locTxBufferWrite - locTxBufferRead) ==
                                (uint8)(UARTT_TX_BUFFER_SIZE - 1u)) );

        if( (locTxBufferRead == locTxBufferWrite) &&
            ((UARTT_TXSTATUS_REG & UARTT_TX_STS_FIFO_FULL) == 0u) )
        {
            /* Add directly to the FIFO */
            UARTT_TXDATA_REG = txDataByte;
        }
        else
        {
            if(locTxBufferWrite >= UARTT_TX_BUFFER_SIZE)
            {
                locTxBufferWrite = 0u;
            }
            /* Add to the software buffer. */
            UARTT_txBuffer[locTxBufferWrite] = txDataByte;
            locTxBufferWrite++;

            /* Finally, update the real output pointer */
        #if ((UARTT_TX_BUFFER_SIZE > UARTT_MAX_BYTE_VALUE) && (CY_PSOC3))
            UARTT_DisableTxInt();
        #endif /* (UARTT_TX_BUFFER_SIZE > UARTT_MAX_BYTE_VALUE) && (CY_PSOC3) */

            UARTT_txBufferWrite = locTxBufferWrite;

        #if ((UARTT_TX_BUFFER_SIZE > UARTT_MAX_BYTE_VALUE) && (CY_PSOC3))
            UARTT_EnableTxInt();
        #endif /* (UARTT_TX_BUFFER_SIZE > UARTT_MAX_BYTE_VALUE) && (CY_PSOC3) */

            if(0u != (UARTT_TXSTATUS_REG & UARTT_TX_STS_FIFO_EMPTY))
            {
                /* Trigger TX interrupt to send software buffer */
                UARTT_SetPendingTxInt();
            }
        }

    #else

        while((UARTT_TXSTATUS_REG & UARTT_TX_STS_FIFO_FULL) != 0u)
        {
            /* Wait for room in the FIFO */
        }

        /* Add directly to the FIFO */
        UARTT_TXDATA_REG = txDataByte;

    #endif /* UARTT_TX_INTERRUPT_ENABLED */
    }


    /*******************************************************************************
    * Function Name: UARTT_PutString
    ********************************************************************************
    *
    * Summary:
    *  Sends a NULL terminated string to the TX buffer for transmission.
    *
    * Parameters:
    *  string[]: Pointer to the null terminated string array residing in RAM or ROM
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTT_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  If there is not enough memory in the TX buffer for the entire string, this
    *  function blocks until the last character of the string is loaded into the
    *  TX buffer.
    *
    *******************************************************************************/
    void UARTT_PutString(const char8 string[]) 
    {
        uint16 bufIndex = 0u;

        /* If not Initialized then skip this function */
        if(UARTT_initVar != 0u)
        {
            /* This is a blocking function, it will not exit until all data is sent */
            while(string[bufIndex] != (char8) 0)
            {
                UARTT_PutChar((uint8)string[bufIndex]);
                bufIndex++;
            }
        }
    }


    /*******************************************************************************
    * Function Name: UARTT_PutArray
    ********************************************************************************
    *
    * Summary:
    *  Places N bytes of data from a memory array into the TX buffer for
    *  transmission.
    *
    * Parameters:
    *  string[]: Address of the memory array residing in RAM or ROM.
    *  byteCount: Number of bytes to be transmitted. The type depends on TX Buffer
    *             Size parameter.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTT_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  If there is not enough memory in the TX buffer for the entire string, this
    *  function blocks until the last character of the string is loaded into the
    *  TX buffer.
    *
    *******************************************************************************/
    void UARTT_PutArray(const uint8 string[], uint8 byteCount)
                                                                    
    {
        uint8 bufIndex = 0u;

        /* If not Initialized then skip this function */
        if(UARTT_initVar != 0u)
        {
            while(bufIndex < byteCount)
            {
                UARTT_PutChar(string[bufIndex]);
                bufIndex++;
            }
        }
    }


    /*******************************************************************************
    * Function Name: UARTT_PutCRLF
    ********************************************************************************
    *
    * Summary:
    *  Writes a byte of data followed by a carriage return (0x0D) and line feed
    *  (0x0A) to the transmit buffer.
    *
    * Parameters:
    *  txDataByte: Data byte to transmit before the carriage return and line feed.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTT_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void UARTT_PutCRLF(uint8 txDataByte) 
    {
        /* If not Initialized then skip this function */
        if(UARTT_initVar != 0u)
        {
            UARTT_PutChar(txDataByte);
            UARTT_PutChar(0x0Du);
            UARTT_PutChar(0x0Au);
        }
    }


    /*******************************************************************************
    * Function Name: UARTT_GetTxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of bytes in the TX buffer which are waiting to be 
    *  transmitted.
    *  * TX software buffer is disabled (TX Buffer Size parameter is equal to 4): 
    *    returns 0 for empty TX FIFO, 1 for not full TX FIFO or 4 for full TX FIFO.
    *  * TX software buffer is enabled: returns the number of bytes in the TX 
    *    software buffer which are waiting to be transmitted. Bytes available in the
    *    TX FIFO do not count.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Number of bytes used in the TX buffer. Return value type depends on the TX 
    *  Buffer Size parameter.
    *
    * Global Variables:
    *  UARTT_txBufferWrite - used to calculate left space.
    *  UARTT_txBufferRead - used to calculate left space.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to find out how full the TX Buffer is.
    *
    *******************************************************************************/
    uint8 UARTT_GetTxBufferSize(void)
                                                            
    {
        uint8 size;

    #if (UARTT_TX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        UARTT_DisableTxInt();

        if(UARTT_txBufferRead == UARTT_txBufferWrite)
        {
            size = 0u;
        }
        else if(UARTT_txBufferRead < UARTT_txBufferWrite)
        {
            size = (UARTT_txBufferWrite - UARTT_txBufferRead);
        }
        else
        {
            size = (UARTT_TX_BUFFER_SIZE - UARTT_txBufferRead) +
                    UARTT_txBufferWrite;
        }

        UARTT_EnableTxInt();

    #else

        size = UARTT_TXSTATUS_REG;

        /* Is the fifo is full. */
        if((size & UARTT_TX_STS_FIFO_FULL) != 0u)
        {
            size = UARTT_FIFO_LENGTH;
        }
        else if((size & UARTT_TX_STS_FIFO_EMPTY) != 0u)
        {
            size = 0u;
        }
        else
        {
            /* We only know there is data in the fifo. */
            size = 1u;
        }

    #endif /* (UARTT_TX_INTERRUPT_ENABLED) */

    return(size);
    }


    /*******************************************************************************
    * Function Name: UARTT_ClearTxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clears all data from the TX buffer and hardware TX FIFO.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTT_txBufferWrite - cleared to zero.
    *  UARTT_txBufferRead - cleared to zero.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Setting the pointers to zero makes the system believe there is no data to
    *  read and writing will resume at address 0 overwriting any data that may have
    *  remained in the RAM.
    *
    * Side Effects:
    *  Data waiting in the transmit buffer is not sent; a byte that is currently
    *  transmitting finishes transmitting.
    *
    *******************************************************************************/
    void UARTT_ClearTxBuffer(void) 
    {
        uint8 enableInterrupts;

        enableInterrupts = CyEnterCriticalSection();
        /* Clear the HW FIFO */
        UARTT_TXDATA_AUX_CTL_REG |= (uint8)  UARTT_TX_FIFO_CLR;
        UARTT_TXDATA_AUX_CTL_REG &= (uint8) ~UARTT_TX_FIFO_CLR;
        CyExitCriticalSection(enableInterrupts);

    #if (UARTT_TX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        UARTT_DisableTxInt();

        UARTT_txBufferRead = 0u;
        UARTT_txBufferWrite = 0u;

        /* Enable Tx interrupt. */
        UARTT_EnableTxInt();

    #endif /* (UARTT_TX_INTERRUPT_ENABLED) */
    }


    /*******************************************************************************
    * Function Name: UARTT_SendBreak
    ********************************************************************************
    *
    * Summary:
    *  Transmits a break signal on the bus.
    *
    * Parameters:
    *  uint8 retMode:  Send Break return mode. See the following table for options.
    *   UARTT_SEND_BREAK - Initialize registers for break, send the Break
    *       signal and return immediately.
    *   UARTT_WAIT_FOR_COMPLETE_REINIT - Wait until break transmission is
    *       complete, reinitialize registers to normal transmission mode then return
    *   UARTT_REINIT - Reinitialize registers to normal transmission mode
    *       then return.
    *   UARTT_SEND_WAIT_REINIT - Performs both options: 
    *      UARTT_SEND_BREAK and UARTT_WAIT_FOR_COMPLETE_REINIT.
    *      This option is recommended for most cases.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTT_initVar - checked to identify that the component has been
    *     initialized.
    *  txPeriod - static variable, used for keeping TX period configuration.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  SendBreak function initializes registers to send 13-bit break signal. It is
    *  important to return the registers configuration to normal for continue 8-bit
    *  operation.
    *  There are 3 variants for this API usage:
    *  1) SendBreak(3) - function will send the Break signal and take care on the
    *     configuration returning. Function will block CPU until transmission
    *     complete.
    *  2) User may want to use blocking time if UART configured to the low speed
    *     operation
    *     Example for this case:
    *     SendBreak(0);     - initialize Break signal transmission
    *         Add your code here to use CPU time
    *     SendBreak(1);     - complete Break operation
    *  3) Same to 2) but user may want to initialize and use the interrupt to
    *     complete break operation.
    *     Example for this case:
    *     Initialize TX interrupt with "TX - On TX Complete" parameter
    *     SendBreak(0);     - initialize Break signal transmission
    *         Add your code here to use CPU time
    *     When interrupt appear with UARTT_TX_STS_COMPLETE status:
    *     SendBreak(2);     - complete Break operation
    *
    * Side Effects:
    *  The UARTT_SendBreak() function initializes registers to send a
    *  break signal.
    *  Break signal length depends on the break signal bits configuration.
    *  The register configuration should be reinitialized before normal 8-bit
    *  communication can continue.
    *
    *******************************************************************************/
    void UARTT_SendBreak(uint8 retMode) 
    {

        /* If not Initialized then skip this function*/
        if(UARTT_initVar != 0u)
        {
            /* Set the Counter to 13-bits and transmit a 00 byte */
            /* When that is done then reset the counter value back */
            uint8 tmpStat;

        #if(UARTT_HD_ENABLED) /* Half Duplex mode*/

            if( (retMode == UARTT_SEND_BREAK) ||
                (retMode == UARTT_SEND_WAIT_REINIT ) )
            {
                /* CTRL_HD_SEND_BREAK - sends break bits in HD mode */
                UARTT_WriteControlRegister(UARTT_ReadControlRegister() |
                                                      UARTT_CTRL_HD_SEND_BREAK);
                /* Send zeros */
                UARTT_TXDATA_REG = 0u;

                do /* Wait until transmit starts */
                {
                    tmpStat = UARTT_TXSTATUS_REG;
                }
                while((tmpStat & UARTT_TX_STS_FIFO_EMPTY) != 0u);
            }

            if( (retMode == UARTT_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == UARTT_SEND_WAIT_REINIT) )
            {
                do /* Wait until transmit complete */
                {
                    tmpStat = UARTT_TXSTATUS_REG;
                }
                while(((uint8)~tmpStat & UARTT_TX_STS_COMPLETE) != 0u);
            }

            if( (retMode == UARTT_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == UARTT_REINIT) ||
                (retMode == UARTT_SEND_WAIT_REINIT) )
            {
                UARTT_WriteControlRegister(UARTT_ReadControlRegister() &
                                              (uint8)~UARTT_CTRL_HD_SEND_BREAK);
            }

        #else /* UARTT_HD_ENABLED Full Duplex mode */

            static uint8 txPeriod;

            if( (retMode == UARTT_SEND_BREAK) ||
                (retMode == UARTT_SEND_WAIT_REINIT) )
            {
                /* CTRL_HD_SEND_BREAK - skip to send parity bit at Break signal in Full Duplex mode */
                #if( (UARTT_PARITY_TYPE != UARTT__B_UART__NONE_REVB) || \
                                    (UARTT_PARITY_TYPE_SW != 0u) )
                    UARTT_WriteControlRegister(UARTT_ReadControlRegister() |
                                                          UARTT_CTRL_HD_SEND_BREAK);
                #endif /* End UARTT_PARITY_TYPE != UARTT__B_UART__NONE_REVB  */

                #if(UARTT_TXCLKGEN_DP)
                    txPeriod = UARTT_TXBITCLKTX_COMPLETE_REG;
                    UARTT_TXBITCLKTX_COMPLETE_REG = UARTT_TXBITCTR_BREAKBITS;
                #else
                    txPeriod = UARTT_TXBITCTR_PERIOD_REG;
                    UARTT_TXBITCTR_PERIOD_REG = UARTT_TXBITCTR_BREAKBITS8X;
                #endif /* End UARTT_TXCLKGEN_DP */

                /* Send zeros */
                UARTT_TXDATA_REG = 0u;

                do /* Wait until transmit starts */
                {
                    tmpStat = UARTT_TXSTATUS_REG;
                }
                while((tmpStat & UARTT_TX_STS_FIFO_EMPTY) != 0u);
            }

            if( (retMode == UARTT_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == UARTT_SEND_WAIT_REINIT) )
            {
                do /* Wait until transmit complete */
                {
                    tmpStat = UARTT_TXSTATUS_REG;
                }
                while(((uint8)~tmpStat & UARTT_TX_STS_COMPLETE) != 0u);
            }

            if( (retMode == UARTT_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == UARTT_REINIT) ||
                (retMode == UARTT_SEND_WAIT_REINIT) )
            {

            #if(UARTT_TXCLKGEN_DP)
                UARTT_TXBITCLKTX_COMPLETE_REG = txPeriod;
            #else
                UARTT_TXBITCTR_PERIOD_REG = txPeriod;
            #endif /* End UARTT_TXCLKGEN_DP */

            #if( (UARTT_PARITY_TYPE != UARTT__B_UART__NONE_REVB) || \
                 (UARTT_PARITY_TYPE_SW != 0u) )
                UARTT_WriteControlRegister(UARTT_ReadControlRegister() &
                                                      (uint8) ~UARTT_CTRL_HD_SEND_BREAK);
            #endif /* End UARTT_PARITY_TYPE != NONE */
            }
        #endif    /* End UARTT_HD_ENABLED */
        }
    }


    /*******************************************************************************
    * Function Name: UARTT_SetTxAddressMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the transmitter to signal the next bytes is address or data.
    *
    * Parameters:
    *  addressMode: 
    *       UARTT_SET_SPACE - Configure the transmitter to send the next
    *                                    byte as a data.
    *       UARTT_SET_MARK  - Configure the transmitter to send the next
    *                                    byte as an address.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  This function sets and clears UARTT_CTRL_MARK bit in the Control
    *  register.
    *
    *******************************************************************************/
    void UARTT_SetTxAddressMode(uint8 addressMode) 
    {
        /* Mark/Space sending enable */
        if(addressMode != 0u)
        {
        #if( UARTT_CONTROL_REG_REMOVED == 0u )
            UARTT_WriteControlRegister(UARTT_ReadControlRegister() |
                                                  UARTT_CTRL_MARK);
        #endif /* End UARTT_CONTROL_REG_REMOVED == 0u */
        }
        else
        {
        #if( UARTT_CONTROL_REG_REMOVED == 0u )
            UARTT_WriteControlRegister(UARTT_ReadControlRegister() &
                                                  (uint8) ~UARTT_CTRL_MARK);
        #endif /* End UARTT_CONTROL_REG_REMOVED == 0u */
        }
    }

#endif  /* EndUARTT_TX_ENABLED */

#if(UARTT_HD_ENABLED)


    /*******************************************************************************
    * Function Name: UARTT_LoadRxConfig
    ********************************************************************************
    *
    * Summary:
    *  Loads the receiver configuration in half duplex mode. After calling this
    *  function, the UART is ready to receive data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  Valid only in half duplex mode. You must make sure that the previous
    *  transaction is complete and it is safe to unload the transmitter
    *  configuration.
    *
    *******************************************************************************/
    void UARTT_LoadRxConfig(void) 
    {
        UARTT_WriteControlRegister(UARTT_ReadControlRegister() &
                                                (uint8)~UARTT_CTRL_HD_SEND);
        UARTT_RXBITCTR_PERIOD_REG = UARTT_HD_RXBITCTR_INIT;

    #if (UARTT_RX_INTERRUPT_ENABLED)
        /* Enable RX interrupt after set RX configuration */
        UARTT_SetRxInterruptMode(UARTT_INIT_RX_INTERRUPTS_MASK);
    #endif /* (UARTT_RX_INTERRUPT_ENABLED) */
    }


    /*******************************************************************************
    * Function Name: UARTT_LoadTxConfig
    ********************************************************************************
    *
    * Summary:
    *  Loads the transmitter configuration in half duplex mode. After calling this
    *  function, the UART is ready to transmit data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  Valid only in half duplex mode. You must make sure that the previous
    *  transaction is complete and it is safe to unload the receiver configuration.
    *
    *******************************************************************************/
    void UARTT_LoadTxConfig(void) 
    {
    #if (UARTT_RX_INTERRUPT_ENABLED)
        /* Disable RX interrupts before set TX configuration */
        UARTT_SetRxInterruptMode(0u);
    #endif /* (UARTT_RX_INTERRUPT_ENABLED) */

        UARTT_WriteControlRegister(UARTT_ReadControlRegister() | UARTT_CTRL_HD_SEND);
        UARTT_RXBITCTR_PERIOD_REG = UARTT_HD_TXBITCTR_INIT;
    }

#endif  /* UARTT_HD_ENABLED */


/* [] END OF FILE */
