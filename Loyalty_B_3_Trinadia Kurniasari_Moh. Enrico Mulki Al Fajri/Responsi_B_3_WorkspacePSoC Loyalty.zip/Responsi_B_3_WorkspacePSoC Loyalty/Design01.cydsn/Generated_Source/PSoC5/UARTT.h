/*******************************************************************************
* File Name: UARTT.h
* Version 2.50
*
* Description:
*  Contains the function prototypes and constants available to the UART
*  user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_UART_UARTT_H)
#define CY_UART_UARTT_H

#include "cyfitter.h"
#include "cytypes.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */


/***************************************
* Conditional Compilation Parameters
***************************************/

#define UARTT_RX_ENABLED                     (1u)
#define UARTT_TX_ENABLED                     (1u)
#define UARTT_HD_ENABLED                     (0u)
#define UARTT_RX_INTERRUPT_ENABLED           (0u)
#define UARTT_TX_INTERRUPT_ENABLED           (0u)
#define UARTT_INTERNAL_CLOCK_USED            (1u)
#define UARTT_RXHW_ADDRESS_ENABLED           (0u)
#define UARTT_OVER_SAMPLE_COUNT              (8u)
#define UARTT_PARITY_TYPE                    (0u)
#define UARTT_PARITY_TYPE_SW                 (0u)
#define UARTT_BREAK_DETECT                   (0u)
#define UARTT_BREAK_BITS_TX                  (13u)
#define UARTT_BREAK_BITS_RX                  (13u)
#define UARTT_TXCLKGEN_DP                    (1u)
#define UARTT_USE23POLLING                   (1u)
#define UARTT_FLOW_CONTROL                   (0u)
#define UARTT_CLK_FREQ                       (0u)
#define UARTT_TX_BUFFER_SIZE                 (4u)
#define UARTT_RX_BUFFER_SIZE                 (4u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component UART_v2_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#if defined(UARTT_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG)
    #define UARTT_CONTROL_REG_REMOVED            (0u)
#else
    #define UARTT_CONTROL_REG_REMOVED            (1u)
#endif /* End UARTT_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */


/***************************************
*      Data Structure Definition
***************************************/

/* Sleep Mode API Support */
typedef struct UARTT_backupStruct_
{
    uint8 enableState;

    #if(UARTT_CONTROL_REG_REMOVED == 0u)
        uint8 cr;
    #endif /* End UARTT_CONTROL_REG_REMOVED */

} UARTT_BACKUP_STRUCT;


/***************************************
*       Function Prototypes
***************************************/

void UARTT_Start(void) ;
void UARTT_Stop(void) ;
uint8 UARTT_ReadControlRegister(void) ;
void UARTT_WriteControlRegister(uint8 control) ;

void UARTT_Init(void) ;
void UARTT_Enable(void) ;
void UARTT_SaveConfig(void) ;
void UARTT_RestoreConfig(void) ;
void UARTT_Sleep(void) ;
void UARTT_Wakeup(void) ;

/* Only if RX is enabled */
#if( (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) )

    #if (UARTT_RX_INTERRUPT_ENABLED)
        #define UARTT_EnableRxInt()  CyIntEnable (UARTT_RX_VECT_NUM)
        #define UARTT_DisableRxInt() CyIntDisable(UARTT_RX_VECT_NUM)
        CY_ISR_PROTO(UARTT_RXISR);
    #endif /* UARTT_RX_INTERRUPT_ENABLED */

    void UARTT_SetRxAddressMode(uint8 addressMode)
                                                           ;
    void UARTT_SetRxAddress1(uint8 address) ;
    void UARTT_SetRxAddress2(uint8 address) ;

    void  UARTT_SetRxInterruptMode(uint8 intSrc) ;
    uint8 UARTT_ReadRxData(void) ;
    uint8 UARTT_ReadRxStatus(void) ;
    uint8 UARTT_GetChar(void) ;
    uint16 UARTT_GetByte(void) ;
    uint8 UARTT_GetRxBufferSize(void)
                                                            ;
    void UARTT_ClearRxBuffer(void) ;

    /* Obsolete functions, defines for backward compatible */
    #define UARTT_GetRxInterruptSource   UARTT_ReadRxStatus

#endif /* End (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) */

/* Only if TX is enabled */
#if(UARTT_TX_ENABLED || UARTT_HD_ENABLED)

    #if(UARTT_TX_INTERRUPT_ENABLED)
        #define UARTT_EnableTxInt()  CyIntEnable (UARTT_TX_VECT_NUM)
        #define UARTT_DisableTxInt() CyIntDisable(UARTT_TX_VECT_NUM)
        #define UARTT_SetPendingTxInt() CyIntSetPending(UARTT_TX_VECT_NUM)
        #define UARTT_ClearPendingTxInt() CyIntClearPending(UARTT_TX_VECT_NUM)
        CY_ISR_PROTO(UARTT_TXISR);
    #endif /* UARTT_TX_INTERRUPT_ENABLED */

    void UARTT_SetTxInterruptMode(uint8 intSrc) ;
    void UARTT_WriteTxData(uint8 txDataByte) ;
    uint8 UARTT_ReadTxStatus(void) ;
    void UARTT_PutChar(uint8 txDataByte) ;
    void UARTT_PutString(const char8 string[]) ;
    void UARTT_PutArray(const uint8 string[], uint8 byteCount)
                                                            ;
    void UARTT_PutCRLF(uint8 txDataByte) ;
    void UARTT_ClearTxBuffer(void) ;
    void UARTT_SetTxAddressMode(uint8 addressMode) ;
    void UARTT_SendBreak(uint8 retMode) ;
    uint8 UARTT_GetTxBufferSize(void)
                                                            ;
    /* Obsolete functions, defines for backward compatible */
    #define UARTT_PutStringConst         UARTT_PutString
    #define UARTT_PutArrayConst          UARTT_PutArray
    #define UARTT_GetTxInterruptSource   UARTT_ReadTxStatus

#endif /* End UARTT_TX_ENABLED || UARTT_HD_ENABLED */

#if(UARTT_HD_ENABLED)
    void UARTT_LoadRxConfig(void) ;
    void UARTT_LoadTxConfig(void) ;
#endif /* End UARTT_HD_ENABLED */


/* Communication bootloader APIs */
#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_UARTT) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))
    /* Physical layer functions */
    void    UARTT_CyBtldrCommStart(void) CYSMALL ;
    void    UARTT_CyBtldrCommStop(void) CYSMALL ;
    void    UARTT_CyBtldrCommReset(void) CYSMALL ;
    cystatus UARTT_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;
    cystatus UARTT_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_UARTT)
        #define CyBtldrCommStart    UARTT_CyBtldrCommStart
        #define CyBtldrCommStop     UARTT_CyBtldrCommStop
        #define CyBtldrCommReset    UARTT_CyBtldrCommReset
        #define CyBtldrCommWrite    UARTT_CyBtldrCommWrite
        #define CyBtldrCommRead     UARTT_CyBtldrCommRead
    #endif  /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_UARTT) */

    /* Byte to Byte time out for detecting end of block data from host */
    #define UARTT_BYTE2BYTE_TIME_OUT (25u)
    #define UARTT_PACKET_EOP         (0x17u) /* End of packet defined by bootloader */
    #define UARTT_WAIT_EOP_DELAY     (5u)    /* Additional 5ms to wait for End of packet */
    #define UARTT_BL_CHK_DELAY_MS    (1u)    /* Time Out quantity equal 1mS */

#endif /* CYDEV_BOOTLOADER_IO_COMP */


/***************************************
*          API Constants
***************************************/
/* Parameters for SetTxAddressMode API*/
#define UARTT_SET_SPACE      (0x00u)
#define UARTT_SET_MARK       (0x01u)

/* Status Register definitions */
#if( (UARTT_TX_ENABLED) || (UARTT_HD_ENABLED) )
    #if(UARTT_TX_INTERRUPT_ENABLED)
        #define UARTT_TX_VECT_NUM            (uint8)UARTT_TXInternalInterrupt__INTC_NUMBER
        #define UARTT_TX_PRIOR_NUM           (uint8)UARTT_TXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* UARTT_TX_INTERRUPT_ENABLED */

    #define UARTT_TX_STS_COMPLETE_SHIFT          (0x00u)
    #define UARTT_TX_STS_FIFO_EMPTY_SHIFT        (0x01u)
    #define UARTT_TX_STS_FIFO_NOT_FULL_SHIFT     (0x03u)
    #if(UARTT_TX_ENABLED)
        #define UARTT_TX_STS_FIFO_FULL_SHIFT     (0x02u)
    #else /* (UARTT_HD_ENABLED) */
        #define UARTT_TX_STS_FIFO_FULL_SHIFT     (0x05u)  /* Needs MD=0 */
    #endif /* (UARTT_TX_ENABLED) */

    #define UARTT_TX_STS_COMPLETE            (uint8)(0x01u << UARTT_TX_STS_COMPLETE_SHIFT)
    #define UARTT_TX_STS_FIFO_EMPTY          (uint8)(0x01u << UARTT_TX_STS_FIFO_EMPTY_SHIFT)
    #define UARTT_TX_STS_FIFO_FULL           (uint8)(0x01u << UARTT_TX_STS_FIFO_FULL_SHIFT)
    #define UARTT_TX_STS_FIFO_NOT_FULL       (uint8)(0x01u << UARTT_TX_STS_FIFO_NOT_FULL_SHIFT)
#endif /* End (UARTT_TX_ENABLED) || (UARTT_HD_ENABLED)*/

#if( (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) )
    #if(UARTT_RX_INTERRUPT_ENABLED)
        #define UARTT_RX_VECT_NUM            (uint8)UARTT_RXInternalInterrupt__INTC_NUMBER
        #define UARTT_RX_PRIOR_NUM           (uint8)UARTT_RXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* UARTT_RX_INTERRUPT_ENABLED */
    #define UARTT_RX_STS_MRKSPC_SHIFT            (0x00u)
    #define UARTT_RX_STS_BREAK_SHIFT             (0x01u)
    #define UARTT_RX_STS_PAR_ERROR_SHIFT         (0x02u)
    #define UARTT_RX_STS_STOP_ERROR_SHIFT        (0x03u)
    #define UARTT_RX_STS_OVERRUN_SHIFT           (0x04u)
    #define UARTT_RX_STS_FIFO_NOTEMPTY_SHIFT     (0x05u)
    #define UARTT_RX_STS_ADDR_MATCH_SHIFT        (0x06u)
    #define UARTT_RX_STS_SOFT_BUFF_OVER_SHIFT    (0x07u)

    #define UARTT_RX_STS_MRKSPC           (uint8)(0x01u << UARTT_RX_STS_MRKSPC_SHIFT)
    #define UARTT_RX_STS_BREAK            (uint8)(0x01u << UARTT_RX_STS_BREAK_SHIFT)
    #define UARTT_RX_STS_PAR_ERROR        (uint8)(0x01u << UARTT_RX_STS_PAR_ERROR_SHIFT)
    #define UARTT_RX_STS_STOP_ERROR       (uint8)(0x01u << UARTT_RX_STS_STOP_ERROR_SHIFT)
    #define UARTT_RX_STS_OVERRUN          (uint8)(0x01u << UARTT_RX_STS_OVERRUN_SHIFT)
    #define UARTT_RX_STS_FIFO_NOTEMPTY    (uint8)(0x01u << UARTT_RX_STS_FIFO_NOTEMPTY_SHIFT)
    #define UARTT_RX_STS_ADDR_MATCH       (uint8)(0x01u << UARTT_RX_STS_ADDR_MATCH_SHIFT)
    #define UARTT_RX_STS_SOFT_BUFF_OVER   (uint8)(0x01u << UARTT_RX_STS_SOFT_BUFF_OVER_SHIFT)
    #define UARTT_RX_HW_MASK                     (0x7Fu)
#endif /* End (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) */

/* Control Register definitions */
#define UARTT_CTRL_HD_SEND_SHIFT                 (0x00u) /* 1 enable TX part in Half Duplex mode */
#define UARTT_CTRL_HD_SEND_BREAK_SHIFT           (0x01u) /* 1 send BREAK signal in Half Duplez mode */
#define UARTT_CTRL_MARK_SHIFT                    (0x02u) /* 1 sets mark, 0 sets space */
#define UARTT_CTRL_PARITY_TYPE0_SHIFT            (0x03u) /* Defines the type of parity implemented */
#define UARTT_CTRL_PARITY_TYPE1_SHIFT            (0x04u) /* Defines the type of parity implemented */
#define UARTT_CTRL_RXADDR_MODE0_SHIFT            (0x05u)
#define UARTT_CTRL_RXADDR_MODE1_SHIFT            (0x06u)
#define UARTT_CTRL_RXADDR_MODE2_SHIFT            (0x07u)

#define UARTT_CTRL_HD_SEND               (uint8)(0x01u << UARTT_CTRL_HD_SEND_SHIFT)
#define UARTT_CTRL_HD_SEND_BREAK         (uint8)(0x01u << UARTT_CTRL_HD_SEND_BREAK_SHIFT)
#define UARTT_CTRL_MARK                  (uint8)(0x01u << UARTT_CTRL_MARK_SHIFT)
#define UARTT_CTRL_PARITY_TYPE_MASK      (uint8)(0x03u << UARTT_CTRL_PARITY_TYPE0_SHIFT)
#define UARTT_CTRL_RXADDR_MODE_MASK      (uint8)(0x07u << UARTT_CTRL_RXADDR_MODE0_SHIFT)

/* StatusI Register Interrupt Enable Control Bits. As defined by the Register map for the AUX Control Register */
#define UARTT_INT_ENABLE                         (0x10u)

/* Bit Counter (7-bit) Control Register Bit Definitions. As defined by the Register map for the AUX Control Register */
#define UARTT_CNTR_ENABLE                        (0x20u)

/*   Constants for SendBreak() "retMode" parameter  */
#define UARTT_SEND_BREAK                         (0x00u)
#define UARTT_WAIT_FOR_COMPLETE_REINIT           (0x01u)
#define UARTT_REINIT                             (0x02u)
#define UARTT_SEND_WAIT_REINIT                   (0x03u)

#define UARTT_OVER_SAMPLE_8                      (8u)
#define UARTT_OVER_SAMPLE_16                     (16u)

#define UARTT_BIT_CENTER                         (UARTT_OVER_SAMPLE_COUNT - 2u)

#define UARTT_FIFO_LENGTH                        (4u)
#define UARTT_NUMBER_OF_START_BIT                (1u)
#define UARTT_MAX_BYTE_VALUE                     (0xFFu)

/* 8X always for count7 implementation */
#define UARTT_TXBITCTR_BREAKBITS8X   ((UARTT_BREAK_BITS_TX * UARTT_OVER_SAMPLE_8) - 1u)
/* 8X or 16X for DP implementation */
#define UARTT_TXBITCTR_BREAKBITS ((UARTT_BREAK_BITS_TX * UARTT_OVER_SAMPLE_COUNT) - 1u)

#define UARTT_HALF_BIT_COUNT   \
                            (((UARTT_OVER_SAMPLE_COUNT / 2u) + (UARTT_USE23POLLING * 1u)) - 2u)
#if (UARTT_OVER_SAMPLE_COUNT == UARTT_OVER_SAMPLE_8)
    #define UARTT_HD_TXBITCTR_INIT   (((UARTT_BREAK_BITS_TX + \
                            UARTT_NUMBER_OF_START_BIT) * UARTT_OVER_SAMPLE_COUNT) - 1u)

    /* This parameter is increased on the 2 in 2 out of 3 mode to sample voting in the middle */
    #define UARTT_RXBITCTR_INIT  ((((UARTT_BREAK_BITS_RX + UARTT_NUMBER_OF_START_BIT) \
                            * UARTT_OVER_SAMPLE_COUNT) + UARTT_HALF_BIT_COUNT) - 1u)

#else /* UARTT_OVER_SAMPLE_COUNT == UARTT_OVER_SAMPLE_16 */
    #define UARTT_HD_TXBITCTR_INIT   ((8u * UARTT_OVER_SAMPLE_COUNT) - 1u)
    /* 7bit counter need one more bit for OverSampleCount = 16 */
    #define UARTT_RXBITCTR_INIT      (((7u * UARTT_OVER_SAMPLE_COUNT) - 1u) + \
                                                      UARTT_HALF_BIT_COUNT)
#endif /* End UARTT_OVER_SAMPLE_COUNT */

#define UARTT_HD_RXBITCTR_INIT                   UARTT_RXBITCTR_INIT


/***************************************
* Global variables external identifier
***************************************/

extern uint8 UARTT_initVar;
#if (UARTT_TX_INTERRUPT_ENABLED && UARTT_TX_ENABLED)
    extern volatile uint8 UARTT_txBuffer[UARTT_TX_BUFFER_SIZE];
    extern volatile uint8 UARTT_txBufferRead;
    extern uint8 UARTT_txBufferWrite;
#endif /* (UARTT_TX_INTERRUPT_ENABLED && UARTT_TX_ENABLED) */
#if (UARTT_RX_INTERRUPT_ENABLED && (UARTT_RX_ENABLED || UARTT_HD_ENABLED))
    extern uint8 UARTT_errorStatus;
    extern volatile uint8 UARTT_rxBuffer[UARTT_RX_BUFFER_SIZE];
    extern volatile uint8 UARTT_rxBufferRead;
    extern volatile uint8 UARTT_rxBufferWrite;
    extern volatile uint8 UARTT_rxBufferLoopDetect;
    extern volatile uint8 UARTT_rxBufferOverflow;
    #if (UARTT_RXHW_ADDRESS_ENABLED)
        extern volatile uint8 UARTT_rxAddressMode;
        extern volatile uint8 UARTT_rxAddressDetected;
    #endif /* (UARTT_RXHW_ADDRESS_ENABLED) */
#endif /* (UARTT_RX_INTERRUPT_ENABLED && (UARTT_RX_ENABLED || UARTT_HD_ENABLED)) */


/***************************************
* Enumerated Types and Parameters
***************************************/

#define UARTT__B_UART__AM_SW_BYTE_BYTE 1
#define UARTT__B_UART__AM_SW_DETECT_TO_BUFFER 2
#define UARTT__B_UART__AM_HW_BYTE_BY_BYTE 3
#define UARTT__B_UART__AM_HW_DETECT_TO_BUFFER 4
#define UARTT__B_UART__AM_NONE 0

#define UARTT__B_UART__NONE_REVB 0
#define UARTT__B_UART__EVEN_REVB 1
#define UARTT__B_UART__ODD_REVB 2
#define UARTT__B_UART__MARK_SPACE_REVB 3



/***************************************
*    Initial Parameter Constants
***************************************/

/* UART shifts max 8 bits, Mark/Space functionality working if 9 selected */
#define UARTT_NUMBER_OF_DATA_BITS    ((8u > 8u) ? 8u : 8u)
#define UARTT_NUMBER_OF_STOP_BITS    (1u)

#if (UARTT_RXHW_ADDRESS_ENABLED)
    #define UARTT_RX_ADDRESS_MODE    (0u)
    #define UARTT_RX_HW_ADDRESS1     (0u)
    #define UARTT_RX_HW_ADDRESS2     (0u)
#endif /* (UARTT_RXHW_ADDRESS_ENABLED) */

#define UARTT_INIT_RX_INTERRUPTS_MASK \
                                  (uint8)((1 << UARTT_RX_STS_FIFO_NOTEMPTY_SHIFT) \
                                        | (0 << UARTT_RX_STS_MRKSPC_SHIFT) \
                                        | (0 << UARTT_RX_STS_ADDR_MATCH_SHIFT) \
                                        | (0 << UARTT_RX_STS_PAR_ERROR_SHIFT) \
                                        | (0 << UARTT_RX_STS_STOP_ERROR_SHIFT) \
                                        | (0 << UARTT_RX_STS_BREAK_SHIFT) \
                                        | (0 << UARTT_RX_STS_OVERRUN_SHIFT))

#define UARTT_INIT_TX_INTERRUPTS_MASK \
                                  (uint8)((0 << UARTT_TX_STS_COMPLETE_SHIFT) \
                                        | (0 << UARTT_TX_STS_FIFO_EMPTY_SHIFT) \
                                        | (0 << UARTT_TX_STS_FIFO_FULL_SHIFT) \
                                        | (0 << UARTT_TX_STS_FIFO_NOT_FULL_SHIFT))


/***************************************
*              Registers
***************************************/

#ifdef UARTT_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define UARTT_CONTROL_REG \
                            (* (reg8 *) UARTT_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
    #define UARTT_CONTROL_PTR \
                            (  (reg8 *) UARTT_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
#endif /* End UARTT_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(UARTT_TX_ENABLED)
    #define UARTT_TXDATA_REG          (* (reg8 *) UARTT_BUART_sTX_TxShifter_u0__F0_REG)
    #define UARTT_TXDATA_PTR          (  (reg8 *) UARTT_BUART_sTX_TxShifter_u0__F0_REG)
    #define UARTT_TXDATA_AUX_CTL_REG  (* (reg8 *) UARTT_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define UARTT_TXDATA_AUX_CTL_PTR  (  (reg8 *) UARTT_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define UARTT_TXSTATUS_REG        (* (reg8 *) UARTT_BUART_sTX_TxSts__STATUS_REG)
    #define UARTT_TXSTATUS_PTR        (  (reg8 *) UARTT_BUART_sTX_TxSts__STATUS_REG)
    #define UARTT_TXSTATUS_MASK_REG   (* (reg8 *) UARTT_BUART_sTX_TxSts__MASK_REG)
    #define UARTT_TXSTATUS_MASK_PTR   (  (reg8 *) UARTT_BUART_sTX_TxSts__MASK_REG)
    #define UARTT_TXSTATUS_ACTL_REG   (* (reg8 *) UARTT_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)
    #define UARTT_TXSTATUS_ACTL_PTR   (  (reg8 *) UARTT_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)

    /* DP clock */
    #if(UARTT_TXCLKGEN_DP)
        #define UARTT_TXBITCLKGEN_CTR_REG        \
                                        (* (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define UARTT_TXBITCLKGEN_CTR_PTR        \
                                        (  (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define UARTT_TXBITCLKTX_COMPLETE_REG    \
                                        (* (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
        #define UARTT_TXBITCLKTX_COMPLETE_PTR    \
                                        (  (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
    #else     /* Count7 clock*/
        #define UARTT_TXBITCTR_PERIOD_REG    \
                                        (* (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define UARTT_TXBITCTR_PERIOD_PTR    \
                                        (  (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define UARTT_TXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define UARTT_TXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define UARTT_TXBITCTR_COUNTER_REG   \
                                        (* (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
        #define UARTT_TXBITCTR_COUNTER_PTR   \
                                        (  (reg8 *) UARTT_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
    #endif /* UARTT_TXCLKGEN_DP */

#endif /* End UARTT_TX_ENABLED */

#if(UARTT_HD_ENABLED)

    #define UARTT_TXDATA_REG             (* (reg8 *) UARTT_BUART_sRX_RxShifter_u0__F1_REG )
    #define UARTT_TXDATA_PTR             (  (reg8 *) UARTT_BUART_sRX_RxShifter_u0__F1_REG )
    #define UARTT_TXDATA_AUX_CTL_REG     (* (reg8 *) UARTT_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)
    #define UARTT_TXDATA_AUX_CTL_PTR     (  (reg8 *) UARTT_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define UARTT_TXSTATUS_REG           (* (reg8 *) UARTT_BUART_sRX_RxSts__STATUS_REG )
    #define UARTT_TXSTATUS_PTR           (  (reg8 *) UARTT_BUART_sRX_RxSts__STATUS_REG )
    #define UARTT_TXSTATUS_MASK_REG      (* (reg8 *) UARTT_BUART_sRX_RxSts__MASK_REG )
    #define UARTT_TXSTATUS_MASK_PTR      (  (reg8 *) UARTT_BUART_sRX_RxSts__MASK_REG )
    #define UARTT_TXSTATUS_ACTL_REG      (* (reg8 *) UARTT_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define UARTT_TXSTATUS_ACTL_PTR      (  (reg8 *) UARTT_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End UARTT_HD_ENABLED */

#if( (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) )
    #define UARTT_RXDATA_REG             (* (reg8 *) UARTT_BUART_sRX_RxShifter_u0__F0_REG )
    #define UARTT_RXDATA_PTR             (  (reg8 *) UARTT_BUART_sRX_RxShifter_u0__F0_REG )
    #define UARTT_RXADDRESS1_REG         (* (reg8 *) UARTT_BUART_sRX_RxShifter_u0__D0_REG )
    #define UARTT_RXADDRESS1_PTR         (  (reg8 *) UARTT_BUART_sRX_RxShifter_u0__D0_REG )
    #define UARTT_RXADDRESS2_REG         (* (reg8 *) UARTT_BUART_sRX_RxShifter_u0__D1_REG )
    #define UARTT_RXADDRESS2_PTR         (  (reg8 *) UARTT_BUART_sRX_RxShifter_u0__D1_REG )
    #define UARTT_RXDATA_AUX_CTL_REG     (* (reg8 *) UARTT_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define UARTT_RXBITCTR_PERIOD_REG    (* (reg8 *) UARTT_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define UARTT_RXBITCTR_PERIOD_PTR    (  (reg8 *) UARTT_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define UARTT_RXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) UARTT_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define UARTT_RXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) UARTT_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define UARTT_RXBITCTR_COUNTER_REG   (* (reg8 *) UARTT_BUART_sRX_RxBitCounter__COUNT_REG )
    #define UARTT_RXBITCTR_COUNTER_PTR   (  (reg8 *) UARTT_BUART_sRX_RxBitCounter__COUNT_REG )

    #define UARTT_RXSTATUS_REG           (* (reg8 *) UARTT_BUART_sRX_RxSts__STATUS_REG )
    #define UARTT_RXSTATUS_PTR           (  (reg8 *) UARTT_BUART_sRX_RxSts__STATUS_REG )
    #define UARTT_RXSTATUS_MASK_REG      (* (reg8 *) UARTT_BUART_sRX_RxSts__MASK_REG )
    #define UARTT_RXSTATUS_MASK_PTR      (  (reg8 *) UARTT_BUART_sRX_RxSts__MASK_REG )
    #define UARTT_RXSTATUS_ACTL_REG      (* (reg8 *) UARTT_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define UARTT_RXSTATUS_ACTL_PTR      (  (reg8 *) UARTT_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End  (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) */

#if(UARTT_INTERNAL_CLOCK_USED)
    /* Register to enable or disable the digital clocks */
    #define UARTT_INTCLOCK_CLKEN_REG     (* (reg8 *) UARTT_IntClock__PM_ACT_CFG)
    #define UARTT_INTCLOCK_CLKEN_PTR     (  (reg8 *) UARTT_IntClock__PM_ACT_CFG)

    /* Clock mask for this clock. */
    #define UARTT_INTCLOCK_CLKEN_MASK    UARTT_IntClock__PM_ACT_MSK
#endif /* End UARTT_INTERNAL_CLOCK_USED */


/***************************************
*       Register Constants
***************************************/

#if(UARTT_TX_ENABLED)
    #define UARTT_TX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End UARTT_TX_ENABLED */

#if(UARTT_HD_ENABLED)
    #define UARTT_TX_FIFO_CLR            (0x02u) /* FIFO1 CLR */
#endif /* End UARTT_HD_ENABLED */

#if( (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) )
    #define UARTT_RX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End  (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

/* UART v2_40 obsolete definitions */
#define UARTT_WAIT_1_MS      UARTT_BL_CHK_DELAY_MS   

#define UARTT_TXBUFFERSIZE   UARTT_TX_BUFFER_SIZE
#define UARTT_RXBUFFERSIZE   UARTT_RX_BUFFER_SIZE

#if (UARTT_RXHW_ADDRESS_ENABLED)
    #define UARTT_RXADDRESSMODE  UARTT_RX_ADDRESS_MODE
    #define UARTT_RXHWADDRESS1   UARTT_RX_HW_ADDRESS1
    #define UARTT_RXHWADDRESS2   UARTT_RX_HW_ADDRESS2
    /* Backward compatible define */
    #define UARTT_RXAddressMode  UARTT_RXADDRESSMODE
#endif /* (UARTT_RXHW_ADDRESS_ENABLED) */

/* UART v2_30 obsolete definitions */
#define UARTT_initvar                    UARTT_initVar

#define UARTT_RX_Enabled                 UARTT_RX_ENABLED
#define UARTT_TX_Enabled                 UARTT_TX_ENABLED
#define UARTT_HD_Enabled                 UARTT_HD_ENABLED
#define UARTT_RX_IntInterruptEnabled     UARTT_RX_INTERRUPT_ENABLED
#define UARTT_TX_IntInterruptEnabled     UARTT_TX_INTERRUPT_ENABLED
#define UARTT_InternalClockUsed          UARTT_INTERNAL_CLOCK_USED
#define UARTT_RXHW_Address_Enabled       UARTT_RXHW_ADDRESS_ENABLED
#define UARTT_OverSampleCount            UARTT_OVER_SAMPLE_COUNT
#define UARTT_ParityType                 UARTT_PARITY_TYPE

#if( UARTT_TX_ENABLED && (UARTT_TXBUFFERSIZE > UARTT_FIFO_LENGTH))
    #define UARTT_TXBUFFER               UARTT_txBuffer
    #define UARTT_TXBUFFERREAD           UARTT_txBufferRead
    #define UARTT_TXBUFFERWRITE          UARTT_txBufferWrite
#endif /* End UARTT_TX_ENABLED */
#if( ( UARTT_RX_ENABLED || UARTT_HD_ENABLED ) && \
     (UARTT_RXBUFFERSIZE > UARTT_FIFO_LENGTH) )
    #define UARTT_RXBUFFER               UARTT_rxBuffer
    #define UARTT_RXBUFFERREAD           UARTT_rxBufferRead
    #define UARTT_RXBUFFERWRITE          UARTT_rxBufferWrite
    #define UARTT_RXBUFFERLOOPDETECT     UARTT_rxBufferLoopDetect
    #define UARTT_RXBUFFER_OVERFLOW      UARTT_rxBufferOverflow
#endif /* End UARTT_RX_ENABLED */

#ifdef UARTT_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define UARTT_CONTROL                UARTT_CONTROL_REG
#endif /* End UARTT_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(UARTT_TX_ENABLED)
    #define UARTT_TXDATA                 UARTT_TXDATA_REG
    #define UARTT_TXSTATUS               UARTT_TXSTATUS_REG
    #define UARTT_TXSTATUS_MASK          UARTT_TXSTATUS_MASK_REG
    #define UARTT_TXSTATUS_ACTL          UARTT_TXSTATUS_ACTL_REG
    /* DP clock */
    #if(UARTT_TXCLKGEN_DP)
        #define UARTT_TXBITCLKGEN_CTR        UARTT_TXBITCLKGEN_CTR_REG
        #define UARTT_TXBITCLKTX_COMPLETE    UARTT_TXBITCLKTX_COMPLETE_REG
    #else     /* Count7 clock*/
        #define UARTT_TXBITCTR_PERIOD        UARTT_TXBITCTR_PERIOD_REG
        #define UARTT_TXBITCTR_CONTROL       UARTT_TXBITCTR_CONTROL_REG
        #define UARTT_TXBITCTR_COUNTER       UARTT_TXBITCTR_COUNTER_REG
    #endif /* UARTT_TXCLKGEN_DP */
#endif /* End UARTT_TX_ENABLED */

#if(UARTT_HD_ENABLED)
    #define UARTT_TXDATA                 UARTT_TXDATA_REG
    #define UARTT_TXSTATUS               UARTT_TXSTATUS_REG
    #define UARTT_TXSTATUS_MASK          UARTT_TXSTATUS_MASK_REG
    #define UARTT_TXSTATUS_ACTL          UARTT_TXSTATUS_ACTL_REG
#endif /* End UARTT_HD_ENABLED */

#if( (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) )
    #define UARTT_RXDATA                 UARTT_RXDATA_REG
    #define UARTT_RXADDRESS1             UARTT_RXADDRESS1_REG
    #define UARTT_RXADDRESS2             UARTT_RXADDRESS2_REG
    #define UARTT_RXBITCTR_PERIOD        UARTT_RXBITCTR_PERIOD_REG
    #define UARTT_RXBITCTR_CONTROL       UARTT_RXBITCTR_CONTROL_REG
    #define UARTT_RXBITCTR_COUNTER       UARTT_RXBITCTR_COUNTER_REG
    #define UARTT_RXSTATUS               UARTT_RXSTATUS_REG
    #define UARTT_RXSTATUS_MASK          UARTT_RXSTATUS_MASK_REG
    #define UARTT_RXSTATUS_ACTL          UARTT_RXSTATUS_ACTL_REG
#endif /* End  (UARTT_RX_ENABLED) || (UARTT_HD_ENABLED) */

#if(UARTT_INTERNAL_CLOCK_USED)
    #define UARTT_INTCLOCK_CLKEN         UARTT_INTCLOCK_CLKEN_REG
#endif /* End UARTT_INTERNAL_CLOCK_USED */

#define UARTT_WAIT_FOR_COMLETE_REINIT    UARTT_WAIT_FOR_COMPLETE_REINIT

#endif  /* CY_UART_UARTT_H */


/* [] END OF FILE */
