/*******************************************************************************
* File Name: UARTR.h
* Version 2.50
*
* Description:
*  Contains the function prototypes and constants available to the UART
*  user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_UART_UARTR_H)
#define CY_UART_UARTR_H

#include "cyfitter.h"
#include "cytypes.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */


/***************************************
* Conditional Compilation Parameters
***************************************/

#define UARTR_RX_ENABLED                     (1u)
#define UARTR_TX_ENABLED                     (1u)
#define UARTR_HD_ENABLED                     (0u)
#define UARTR_RX_INTERRUPT_ENABLED           (0u)
#define UARTR_TX_INTERRUPT_ENABLED           (0u)
#define UARTR_INTERNAL_CLOCK_USED            (1u)
#define UARTR_RXHW_ADDRESS_ENABLED           (0u)
#define UARTR_OVER_SAMPLE_COUNT              (8u)
#define UARTR_PARITY_TYPE                    (0u)
#define UARTR_PARITY_TYPE_SW                 (0u)
#define UARTR_BREAK_DETECT                   (0u)
#define UARTR_BREAK_BITS_TX                  (13u)
#define UARTR_BREAK_BITS_RX                  (13u)
#define UARTR_TXCLKGEN_DP                    (1u)
#define UARTR_USE23POLLING                   (1u)
#define UARTR_FLOW_CONTROL                   (0u)
#define UARTR_CLK_FREQ                       (0u)
#define UARTR_TX_BUFFER_SIZE                 (4u)
#define UARTR_RX_BUFFER_SIZE                 (4u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component UART_v2_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#if defined(UARTR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG)
    #define UARTR_CONTROL_REG_REMOVED            (0u)
#else
    #define UARTR_CONTROL_REG_REMOVED            (1u)
#endif /* End UARTR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */


/***************************************
*      Data Structure Definition
***************************************/

/* Sleep Mode API Support */
typedef struct UARTR_backupStruct_
{
    uint8 enableState;

    #if(UARTR_CONTROL_REG_REMOVED == 0u)
        uint8 cr;
    #endif /* End UARTR_CONTROL_REG_REMOVED */

} UARTR_BACKUP_STRUCT;


/***************************************
*       Function Prototypes
***************************************/

void UARTR_Start(void) ;
void UARTR_Stop(void) ;
uint8 UARTR_ReadControlRegister(void) ;
void UARTR_WriteControlRegister(uint8 control) ;

void UARTR_Init(void) ;
void UARTR_Enable(void) ;
void UARTR_SaveConfig(void) ;
void UARTR_RestoreConfig(void) ;
void UARTR_Sleep(void) ;
void UARTR_Wakeup(void) ;

/* Only if RX is enabled */
#if( (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) )

    #if (UARTR_RX_INTERRUPT_ENABLED)
        #define UARTR_EnableRxInt()  CyIntEnable (UARTR_RX_VECT_NUM)
        #define UARTR_DisableRxInt() CyIntDisable(UARTR_RX_VECT_NUM)
        CY_ISR_PROTO(UARTR_RXISR);
    #endif /* UARTR_RX_INTERRUPT_ENABLED */

    void UARTR_SetRxAddressMode(uint8 addressMode)
                                                           ;
    void UARTR_SetRxAddress1(uint8 address) ;
    void UARTR_SetRxAddress2(uint8 address) ;

    void  UARTR_SetRxInterruptMode(uint8 intSrc) ;
    uint8 UARTR_ReadRxData(void) ;
    uint8 UARTR_ReadRxStatus(void) ;
    uint8 UARTR_GetChar(void) ;
    uint16 UARTR_GetByte(void) ;
    uint8 UARTR_GetRxBufferSize(void)
                                                            ;
    void UARTR_ClearRxBuffer(void) ;

    /* Obsolete functions, defines for backward compatible */
    #define UARTR_GetRxInterruptSource   UARTR_ReadRxStatus

#endif /* End (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) */

/* Only if TX is enabled */
#if(UARTR_TX_ENABLED || UARTR_HD_ENABLED)

    #if(UARTR_TX_INTERRUPT_ENABLED)
        #define UARTR_EnableTxInt()  CyIntEnable (UARTR_TX_VECT_NUM)
        #define UARTR_DisableTxInt() CyIntDisable(UARTR_TX_VECT_NUM)
        #define UARTR_SetPendingTxInt() CyIntSetPending(UARTR_TX_VECT_NUM)
        #define UARTR_ClearPendingTxInt() CyIntClearPending(UARTR_TX_VECT_NUM)
        CY_ISR_PROTO(UARTR_TXISR);
    #endif /* UARTR_TX_INTERRUPT_ENABLED */

    void UARTR_SetTxInterruptMode(uint8 intSrc) ;
    void UARTR_WriteTxData(uint8 txDataByte) ;
    uint8 UARTR_ReadTxStatus(void) ;
    void UARTR_PutChar(uint8 txDataByte) ;
    void UARTR_PutString(const char8 string[]) ;
    void UARTR_PutArray(const uint8 string[], uint8 byteCount)
                                                            ;
    void UARTR_PutCRLF(uint8 txDataByte) ;
    void UARTR_ClearTxBuffer(void) ;
    void UARTR_SetTxAddressMode(uint8 addressMode) ;
    void UARTR_SendBreak(uint8 retMode) ;
    uint8 UARTR_GetTxBufferSize(void)
                                                            ;
    /* Obsolete functions, defines for backward compatible */
    #define UARTR_PutStringConst         UARTR_PutString
    #define UARTR_PutArrayConst          UARTR_PutArray
    #define UARTR_GetTxInterruptSource   UARTR_ReadTxStatus

#endif /* End UARTR_TX_ENABLED || UARTR_HD_ENABLED */

#if(UARTR_HD_ENABLED)
    void UARTR_LoadRxConfig(void) ;
    void UARTR_LoadTxConfig(void) ;
#endif /* End UARTR_HD_ENABLED */


/* Communication bootloader APIs */
#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_UARTR) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))
    /* Physical layer functions */
    void    UARTR_CyBtldrCommStart(void) CYSMALL ;
    void    UARTR_CyBtldrCommStop(void) CYSMALL ;
    void    UARTR_CyBtldrCommReset(void) CYSMALL ;
    cystatus UARTR_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;
    cystatus UARTR_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_UARTR)
        #define CyBtldrCommStart    UARTR_CyBtldrCommStart
        #define CyBtldrCommStop     UARTR_CyBtldrCommStop
        #define CyBtldrCommReset    UARTR_CyBtldrCommReset
        #define CyBtldrCommWrite    UARTR_CyBtldrCommWrite
        #define CyBtldrCommRead     UARTR_CyBtldrCommRead
    #endif  /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_UARTR) */

    /* Byte to Byte time out for detecting end of block data from host */
    #define UARTR_BYTE2BYTE_TIME_OUT (25u)
    #define UARTR_PACKET_EOP         (0x17u) /* End of packet defined by bootloader */
    #define UARTR_WAIT_EOP_DELAY     (5u)    /* Additional 5ms to wait for End of packet */
    #define UARTR_BL_CHK_DELAY_MS    (1u)    /* Time Out quantity equal 1mS */

#endif /* CYDEV_BOOTLOADER_IO_COMP */


/***************************************
*          API Constants
***************************************/
/* Parameters for SetTxAddressMode API*/
#define UARTR_SET_SPACE      (0x00u)
#define UARTR_SET_MARK       (0x01u)

/* Status Register definitions */
#if( (UARTR_TX_ENABLED) || (UARTR_HD_ENABLED) )
    #if(UARTR_TX_INTERRUPT_ENABLED)
        #define UARTR_TX_VECT_NUM            (uint8)UARTR_TXInternalInterrupt__INTC_NUMBER
        #define UARTR_TX_PRIOR_NUM           (uint8)UARTR_TXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* UARTR_TX_INTERRUPT_ENABLED */

    #define UARTR_TX_STS_COMPLETE_SHIFT          (0x00u)
    #define UARTR_TX_STS_FIFO_EMPTY_SHIFT        (0x01u)
    #define UARTR_TX_STS_FIFO_NOT_FULL_SHIFT     (0x03u)
    #if(UARTR_TX_ENABLED)
        #define UARTR_TX_STS_FIFO_FULL_SHIFT     (0x02u)
    #else /* (UARTR_HD_ENABLED) */
        #define UARTR_TX_STS_FIFO_FULL_SHIFT     (0x05u)  /* Needs MD=0 */
    #endif /* (UARTR_TX_ENABLED) */

    #define UARTR_TX_STS_COMPLETE            (uint8)(0x01u << UARTR_TX_STS_COMPLETE_SHIFT)
    #define UARTR_TX_STS_FIFO_EMPTY          (uint8)(0x01u << UARTR_TX_STS_FIFO_EMPTY_SHIFT)
    #define UARTR_TX_STS_FIFO_FULL           (uint8)(0x01u << UARTR_TX_STS_FIFO_FULL_SHIFT)
    #define UARTR_TX_STS_FIFO_NOT_FULL       (uint8)(0x01u << UARTR_TX_STS_FIFO_NOT_FULL_SHIFT)
#endif /* End (UARTR_TX_ENABLED) || (UARTR_HD_ENABLED)*/

#if( (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) )
    #if(UARTR_RX_INTERRUPT_ENABLED)
        #define UARTR_RX_VECT_NUM            (uint8)UARTR_RXInternalInterrupt__INTC_NUMBER
        #define UARTR_RX_PRIOR_NUM           (uint8)UARTR_RXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* UARTR_RX_INTERRUPT_ENABLED */
    #define UARTR_RX_STS_MRKSPC_SHIFT            (0x00u)
    #define UARTR_RX_STS_BREAK_SHIFT             (0x01u)
    #define UARTR_RX_STS_PAR_ERROR_SHIFT         (0x02u)
    #define UARTR_RX_STS_STOP_ERROR_SHIFT        (0x03u)
    #define UARTR_RX_STS_OVERRUN_SHIFT           (0x04u)
    #define UARTR_RX_STS_FIFO_NOTEMPTY_SHIFT     (0x05u)
    #define UARTR_RX_STS_ADDR_MATCH_SHIFT        (0x06u)
    #define UARTR_RX_STS_SOFT_BUFF_OVER_SHIFT    (0x07u)

    #define UARTR_RX_STS_MRKSPC           (uint8)(0x01u << UARTR_RX_STS_MRKSPC_SHIFT)
    #define UARTR_RX_STS_BREAK            (uint8)(0x01u << UARTR_RX_STS_BREAK_SHIFT)
    #define UARTR_RX_STS_PAR_ERROR        (uint8)(0x01u << UARTR_RX_STS_PAR_ERROR_SHIFT)
    #define UARTR_RX_STS_STOP_ERROR       (uint8)(0x01u << UARTR_RX_STS_STOP_ERROR_SHIFT)
    #define UARTR_RX_STS_OVERRUN          (uint8)(0x01u << UARTR_RX_STS_OVERRUN_SHIFT)
    #define UARTR_RX_STS_FIFO_NOTEMPTY    (uint8)(0x01u << UARTR_RX_STS_FIFO_NOTEMPTY_SHIFT)
    #define UARTR_RX_STS_ADDR_MATCH       (uint8)(0x01u << UARTR_RX_STS_ADDR_MATCH_SHIFT)
    #define UARTR_RX_STS_SOFT_BUFF_OVER   (uint8)(0x01u << UARTR_RX_STS_SOFT_BUFF_OVER_SHIFT)
    #define UARTR_RX_HW_MASK                     (0x7Fu)
#endif /* End (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) */

/* Control Register definitions */
#define UARTR_CTRL_HD_SEND_SHIFT                 (0x00u) /* 1 enable TX part in Half Duplex mode */
#define UARTR_CTRL_HD_SEND_BREAK_SHIFT           (0x01u) /* 1 send BREAK signal in Half Duplez mode */
#define UARTR_CTRL_MARK_SHIFT                    (0x02u) /* 1 sets mark, 0 sets space */
#define UARTR_CTRL_PARITY_TYPE0_SHIFT            (0x03u) /* Defines the type of parity implemented */
#define UARTR_CTRL_PARITY_TYPE1_SHIFT            (0x04u) /* Defines the type of parity implemented */
#define UARTR_CTRL_RXADDR_MODE0_SHIFT            (0x05u)
#define UARTR_CTRL_RXADDR_MODE1_SHIFT            (0x06u)
#define UARTR_CTRL_RXADDR_MODE2_SHIFT            (0x07u)

#define UARTR_CTRL_HD_SEND               (uint8)(0x01u << UARTR_CTRL_HD_SEND_SHIFT)
#define UARTR_CTRL_HD_SEND_BREAK         (uint8)(0x01u << UARTR_CTRL_HD_SEND_BREAK_SHIFT)
#define UARTR_CTRL_MARK                  (uint8)(0x01u << UARTR_CTRL_MARK_SHIFT)
#define UARTR_CTRL_PARITY_TYPE_MASK      (uint8)(0x03u << UARTR_CTRL_PARITY_TYPE0_SHIFT)
#define UARTR_CTRL_RXADDR_MODE_MASK      (uint8)(0x07u << UARTR_CTRL_RXADDR_MODE0_SHIFT)

/* StatusI Register Interrupt Enable Control Bits. As defined by the Register map for the AUX Control Register */
#define UARTR_INT_ENABLE                         (0x10u)

/* Bit Counter (7-bit) Control Register Bit Definitions. As defined by the Register map for the AUX Control Register */
#define UARTR_CNTR_ENABLE                        (0x20u)

/*   Constants for SendBreak() "retMode" parameter  */
#define UARTR_SEND_BREAK                         (0x00u)
#define UARTR_WAIT_FOR_COMPLETE_REINIT           (0x01u)
#define UARTR_REINIT                             (0x02u)
#define UARTR_SEND_WAIT_REINIT                   (0x03u)

#define UARTR_OVER_SAMPLE_8                      (8u)
#define UARTR_OVER_SAMPLE_16                     (16u)

#define UARTR_BIT_CENTER                         (UARTR_OVER_SAMPLE_COUNT - 2u)

#define UARTR_FIFO_LENGTH                        (4u)
#define UARTR_NUMBER_OF_START_BIT                (1u)
#define UARTR_MAX_BYTE_VALUE                     (0xFFu)

/* 8X always for count7 implementation */
#define UARTR_TXBITCTR_BREAKBITS8X   ((UARTR_BREAK_BITS_TX * UARTR_OVER_SAMPLE_8) - 1u)
/* 8X or 16X for DP implementation */
#define UARTR_TXBITCTR_BREAKBITS ((UARTR_BREAK_BITS_TX * UARTR_OVER_SAMPLE_COUNT) - 1u)

#define UARTR_HALF_BIT_COUNT   \
                            (((UARTR_OVER_SAMPLE_COUNT / 2u) + (UARTR_USE23POLLING * 1u)) - 2u)
#if (UARTR_OVER_SAMPLE_COUNT == UARTR_OVER_SAMPLE_8)
    #define UARTR_HD_TXBITCTR_INIT   (((UARTR_BREAK_BITS_TX + \
                            UARTR_NUMBER_OF_START_BIT) * UARTR_OVER_SAMPLE_COUNT) - 1u)

    /* This parameter is increased on the 2 in 2 out of 3 mode to sample voting in the middle */
    #define UARTR_RXBITCTR_INIT  ((((UARTR_BREAK_BITS_RX + UARTR_NUMBER_OF_START_BIT) \
                            * UARTR_OVER_SAMPLE_COUNT) + UARTR_HALF_BIT_COUNT) - 1u)

#else /* UARTR_OVER_SAMPLE_COUNT == UARTR_OVER_SAMPLE_16 */
    #define UARTR_HD_TXBITCTR_INIT   ((8u * UARTR_OVER_SAMPLE_COUNT) - 1u)
    /* 7bit counter need one more bit for OverSampleCount = 16 */
    #define UARTR_RXBITCTR_INIT      (((7u * UARTR_OVER_SAMPLE_COUNT) - 1u) + \
                                                      UARTR_HALF_BIT_COUNT)
#endif /* End UARTR_OVER_SAMPLE_COUNT */

#define UARTR_HD_RXBITCTR_INIT                   UARTR_RXBITCTR_INIT


/***************************************
* Global variables external identifier
***************************************/

extern uint8 UARTR_initVar;
#if (UARTR_TX_INTERRUPT_ENABLED && UARTR_TX_ENABLED)
    extern volatile uint8 UARTR_txBuffer[UARTR_TX_BUFFER_SIZE];
    extern volatile uint8 UARTR_txBufferRead;
    extern uint8 UARTR_txBufferWrite;
#endif /* (UARTR_TX_INTERRUPT_ENABLED && UARTR_TX_ENABLED) */
#if (UARTR_RX_INTERRUPT_ENABLED && (UARTR_RX_ENABLED || UARTR_HD_ENABLED))
    extern uint8 UARTR_errorStatus;
    extern volatile uint8 UARTR_rxBuffer[UARTR_RX_BUFFER_SIZE];
    extern volatile uint8 UARTR_rxBufferRead;
    extern volatile uint8 UARTR_rxBufferWrite;
    extern volatile uint8 UARTR_rxBufferLoopDetect;
    extern volatile uint8 UARTR_rxBufferOverflow;
    #if (UARTR_RXHW_ADDRESS_ENABLED)
        extern volatile uint8 UARTR_rxAddressMode;
        extern volatile uint8 UARTR_rxAddressDetected;
    #endif /* (UARTR_RXHW_ADDRESS_ENABLED) */
#endif /* (UARTR_RX_INTERRUPT_ENABLED && (UARTR_RX_ENABLED || UARTR_HD_ENABLED)) */


/***************************************
* Enumerated Types and Parameters
***************************************/

#define UARTR__B_UART__AM_SW_BYTE_BYTE 1
#define UARTR__B_UART__AM_SW_DETECT_TO_BUFFER 2
#define UARTR__B_UART__AM_HW_BYTE_BY_BYTE 3
#define UARTR__B_UART__AM_HW_DETECT_TO_BUFFER 4
#define UARTR__B_UART__AM_NONE 0

#define UARTR__B_UART__NONE_REVB 0
#define UARTR__B_UART__EVEN_REVB 1
#define UARTR__B_UART__ODD_REVB 2
#define UARTR__B_UART__MARK_SPACE_REVB 3



/***************************************
*    Initial Parameter Constants
***************************************/

/* UART shifts max 8 bits, Mark/Space functionality working if 9 selected */
#define UARTR_NUMBER_OF_DATA_BITS    ((8u > 8u) ? 8u : 8u)
#define UARTR_NUMBER_OF_STOP_BITS    (1u)

#if (UARTR_RXHW_ADDRESS_ENABLED)
    #define UARTR_RX_ADDRESS_MODE    (0u)
    #define UARTR_RX_HW_ADDRESS1     (0u)
    #define UARTR_RX_HW_ADDRESS2     (0u)
#endif /* (UARTR_RXHW_ADDRESS_ENABLED) */

#define UARTR_INIT_RX_INTERRUPTS_MASK \
                                  (uint8)((1 << UARTR_RX_STS_FIFO_NOTEMPTY_SHIFT) \
                                        | (0 << UARTR_RX_STS_MRKSPC_SHIFT) \
                                        | (0 << UARTR_RX_STS_ADDR_MATCH_SHIFT) \
                                        | (0 << UARTR_RX_STS_PAR_ERROR_SHIFT) \
                                        | (0 << UARTR_RX_STS_STOP_ERROR_SHIFT) \
                                        | (0 << UARTR_RX_STS_BREAK_SHIFT) \
                                        | (0 << UARTR_RX_STS_OVERRUN_SHIFT))

#define UARTR_INIT_TX_INTERRUPTS_MASK \
                                  (uint8)((0 << UARTR_TX_STS_COMPLETE_SHIFT) \
                                        | (0 << UARTR_TX_STS_FIFO_EMPTY_SHIFT) \
                                        | (0 << UARTR_TX_STS_FIFO_FULL_SHIFT) \
                                        | (0 << UARTR_TX_STS_FIFO_NOT_FULL_SHIFT))


/***************************************
*              Registers
***************************************/

#ifdef UARTR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define UARTR_CONTROL_REG \
                            (* (reg8 *) UARTR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
    #define UARTR_CONTROL_PTR \
                            (  (reg8 *) UARTR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
#endif /* End UARTR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(UARTR_TX_ENABLED)
    #define UARTR_TXDATA_REG          (* (reg8 *) UARTR_BUART_sTX_TxShifter_u0__F0_REG)
    #define UARTR_TXDATA_PTR          (  (reg8 *) UARTR_BUART_sTX_TxShifter_u0__F0_REG)
    #define UARTR_TXDATA_AUX_CTL_REG  (* (reg8 *) UARTR_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define UARTR_TXDATA_AUX_CTL_PTR  (  (reg8 *) UARTR_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define UARTR_TXSTATUS_REG        (* (reg8 *) UARTR_BUART_sTX_TxSts__STATUS_REG)
    #define UARTR_TXSTATUS_PTR        (  (reg8 *) UARTR_BUART_sTX_TxSts__STATUS_REG)
    #define UARTR_TXSTATUS_MASK_REG   (* (reg8 *) UARTR_BUART_sTX_TxSts__MASK_REG)
    #define UARTR_TXSTATUS_MASK_PTR   (  (reg8 *) UARTR_BUART_sTX_TxSts__MASK_REG)
    #define UARTR_TXSTATUS_ACTL_REG   (* (reg8 *) UARTR_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)
    #define UARTR_TXSTATUS_ACTL_PTR   (  (reg8 *) UARTR_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)

    /* DP clock */
    #if(UARTR_TXCLKGEN_DP)
        #define UARTR_TXBITCLKGEN_CTR_REG        \
                                        (* (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define UARTR_TXBITCLKGEN_CTR_PTR        \
                                        (  (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define UARTR_TXBITCLKTX_COMPLETE_REG    \
                                        (* (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
        #define UARTR_TXBITCLKTX_COMPLETE_PTR    \
                                        (  (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
    #else     /* Count7 clock*/
        #define UARTR_TXBITCTR_PERIOD_REG    \
                                        (* (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define UARTR_TXBITCTR_PERIOD_PTR    \
                                        (  (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define UARTR_TXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define UARTR_TXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define UARTR_TXBITCTR_COUNTER_REG   \
                                        (* (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
        #define UARTR_TXBITCTR_COUNTER_PTR   \
                                        (  (reg8 *) UARTR_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
    #endif /* UARTR_TXCLKGEN_DP */

#endif /* End UARTR_TX_ENABLED */

#if(UARTR_HD_ENABLED)

    #define UARTR_TXDATA_REG             (* (reg8 *) UARTR_BUART_sRX_RxShifter_u0__F1_REG )
    #define UARTR_TXDATA_PTR             (  (reg8 *) UARTR_BUART_sRX_RxShifter_u0__F1_REG )
    #define UARTR_TXDATA_AUX_CTL_REG     (* (reg8 *) UARTR_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)
    #define UARTR_TXDATA_AUX_CTL_PTR     (  (reg8 *) UARTR_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define UARTR_TXSTATUS_REG           (* (reg8 *) UARTR_BUART_sRX_RxSts__STATUS_REG )
    #define UARTR_TXSTATUS_PTR           (  (reg8 *) UARTR_BUART_sRX_RxSts__STATUS_REG )
    #define UARTR_TXSTATUS_MASK_REG      (* (reg8 *) UARTR_BUART_sRX_RxSts__MASK_REG )
    #define UARTR_TXSTATUS_MASK_PTR      (  (reg8 *) UARTR_BUART_sRX_RxSts__MASK_REG )
    #define UARTR_TXSTATUS_ACTL_REG      (* (reg8 *) UARTR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define UARTR_TXSTATUS_ACTL_PTR      (  (reg8 *) UARTR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End UARTR_HD_ENABLED */

#if( (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) )
    #define UARTR_RXDATA_REG             (* (reg8 *) UARTR_BUART_sRX_RxShifter_u0__F0_REG )
    #define UARTR_RXDATA_PTR             (  (reg8 *) UARTR_BUART_sRX_RxShifter_u0__F0_REG )
    #define UARTR_RXADDRESS1_REG         (* (reg8 *) UARTR_BUART_sRX_RxShifter_u0__D0_REG )
    #define UARTR_RXADDRESS1_PTR         (  (reg8 *) UARTR_BUART_sRX_RxShifter_u0__D0_REG )
    #define UARTR_RXADDRESS2_REG         (* (reg8 *) UARTR_BUART_sRX_RxShifter_u0__D1_REG )
    #define UARTR_RXADDRESS2_PTR         (  (reg8 *) UARTR_BUART_sRX_RxShifter_u0__D1_REG )
    #define UARTR_RXDATA_AUX_CTL_REG     (* (reg8 *) UARTR_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define UARTR_RXBITCTR_PERIOD_REG    (* (reg8 *) UARTR_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define UARTR_RXBITCTR_PERIOD_PTR    (  (reg8 *) UARTR_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define UARTR_RXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) UARTR_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define UARTR_RXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) UARTR_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define UARTR_RXBITCTR_COUNTER_REG   (* (reg8 *) UARTR_BUART_sRX_RxBitCounter__COUNT_REG )
    #define UARTR_RXBITCTR_COUNTER_PTR   (  (reg8 *) UARTR_BUART_sRX_RxBitCounter__COUNT_REG )

    #define UARTR_RXSTATUS_REG           (* (reg8 *) UARTR_BUART_sRX_RxSts__STATUS_REG )
    #define UARTR_RXSTATUS_PTR           (  (reg8 *) UARTR_BUART_sRX_RxSts__STATUS_REG )
    #define UARTR_RXSTATUS_MASK_REG      (* (reg8 *) UARTR_BUART_sRX_RxSts__MASK_REG )
    #define UARTR_RXSTATUS_MASK_PTR      (  (reg8 *) UARTR_BUART_sRX_RxSts__MASK_REG )
    #define UARTR_RXSTATUS_ACTL_REG      (* (reg8 *) UARTR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define UARTR_RXSTATUS_ACTL_PTR      (  (reg8 *) UARTR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End  (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) */

#if(UARTR_INTERNAL_CLOCK_USED)
    /* Register to enable or disable the digital clocks */
    #define UARTR_INTCLOCK_CLKEN_REG     (* (reg8 *) UARTR_IntClock__PM_ACT_CFG)
    #define UARTR_INTCLOCK_CLKEN_PTR     (  (reg8 *) UARTR_IntClock__PM_ACT_CFG)

    /* Clock mask for this clock. */
    #define UARTR_INTCLOCK_CLKEN_MASK    UARTR_IntClock__PM_ACT_MSK
#endif /* End UARTR_INTERNAL_CLOCK_USED */


/***************************************
*       Register Constants
***************************************/

#if(UARTR_TX_ENABLED)
    #define UARTR_TX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End UARTR_TX_ENABLED */

#if(UARTR_HD_ENABLED)
    #define UARTR_TX_FIFO_CLR            (0x02u) /* FIFO1 CLR */
#endif /* End UARTR_HD_ENABLED */

#if( (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) )
    #define UARTR_RX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End  (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

/* UART v2_40 obsolete definitions */
#define UARTR_WAIT_1_MS      UARTR_BL_CHK_DELAY_MS   

#define UARTR_TXBUFFERSIZE   UARTR_TX_BUFFER_SIZE
#define UARTR_RXBUFFERSIZE   UARTR_RX_BUFFER_SIZE

#if (UARTR_RXHW_ADDRESS_ENABLED)
    #define UARTR_RXADDRESSMODE  UARTR_RX_ADDRESS_MODE
    #define UARTR_RXHWADDRESS1   UARTR_RX_HW_ADDRESS1
    #define UARTR_RXHWADDRESS2   UARTR_RX_HW_ADDRESS2
    /* Backward compatible define */
    #define UARTR_RXAddressMode  UARTR_RXADDRESSMODE
#endif /* (UARTR_RXHW_ADDRESS_ENABLED) */

/* UART v2_30 obsolete definitions */
#define UARTR_initvar                    UARTR_initVar

#define UARTR_RX_Enabled                 UARTR_RX_ENABLED
#define UARTR_TX_Enabled                 UARTR_TX_ENABLED
#define UARTR_HD_Enabled                 UARTR_HD_ENABLED
#define UARTR_RX_IntInterruptEnabled     UARTR_RX_INTERRUPT_ENABLED
#define UARTR_TX_IntInterruptEnabled     UARTR_TX_INTERRUPT_ENABLED
#define UARTR_InternalClockUsed          UARTR_INTERNAL_CLOCK_USED
#define UARTR_RXHW_Address_Enabled       UARTR_RXHW_ADDRESS_ENABLED
#define UARTR_OverSampleCount            UARTR_OVER_SAMPLE_COUNT
#define UARTR_ParityType                 UARTR_PARITY_TYPE

#if( UARTR_TX_ENABLED && (UARTR_TXBUFFERSIZE > UARTR_FIFO_LENGTH))
    #define UARTR_TXBUFFER               UARTR_txBuffer
    #define UARTR_TXBUFFERREAD           UARTR_txBufferRead
    #define UARTR_TXBUFFERWRITE          UARTR_txBufferWrite
#endif /* End UARTR_TX_ENABLED */
#if( ( UARTR_RX_ENABLED || UARTR_HD_ENABLED ) && \
     (UARTR_RXBUFFERSIZE > UARTR_FIFO_LENGTH) )
    #define UARTR_RXBUFFER               UARTR_rxBuffer
    #define UARTR_RXBUFFERREAD           UARTR_rxBufferRead
    #define UARTR_RXBUFFERWRITE          UARTR_rxBufferWrite
    #define UARTR_RXBUFFERLOOPDETECT     UARTR_rxBufferLoopDetect
    #define UARTR_RXBUFFER_OVERFLOW      UARTR_rxBufferOverflow
#endif /* End UARTR_RX_ENABLED */

#ifdef UARTR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define UARTR_CONTROL                UARTR_CONTROL_REG
#endif /* End UARTR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(UARTR_TX_ENABLED)
    #define UARTR_TXDATA                 UARTR_TXDATA_REG
    #define UARTR_TXSTATUS               UARTR_TXSTATUS_REG
    #define UARTR_TXSTATUS_MASK          UARTR_TXSTATUS_MASK_REG
    #define UARTR_TXSTATUS_ACTL          UARTR_TXSTATUS_ACTL_REG
    /* DP clock */
    #if(UARTR_TXCLKGEN_DP)
        #define UARTR_TXBITCLKGEN_CTR        UARTR_TXBITCLKGEN_CTR_REG
        #define UARTR_TXBITCLKTX_COMPLETE    UARTR_TXBITCLKTX_COMPLETE_REG
    #else     /* Count7 clock*/
        #define UARTR_TXBITCTR_PERIOD        UARTR_TXBITCTR_PERIOD_REG
        #define UARTR_TXBITCTR_CONTROL       UARTR_TXBITCTR_CONTROL_REG
        #define UARTR_TXBITCTR_COUNTER       UARTR_TXBITCTR_COUNTER_REG
    #endif /* UARTR_TXCLKGEN_DP */
#endif /* End UARTR_TX_ENABLED */

#if(UARTR_HD_ENABLED)
    #define UARTR_TXDATA                 UARTR_TXDATA_REG
    #define UARTR_TXSTATUS               UARTR_TXSTATUS_REG
    #define UARTR_TXSTATUS_MASK          UARTR_TXSTATUS_MASK_REG
    #define UARTR_TXSTATUS_ACTL          UARTR_TXSTATUS_ACTL_REG
#endif /* End UARTR_HD_ENABLED */

#if( (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) )
    #define UARTR_RXDATA                 UARTR_RXDATA_REG
    #define UARTR_RXADDRESS1             UARTR_RXADDRESS1_REG
    #define UARTR_RXADDRESS2             UARTR_RXADDRESS2_REG
    #define UARTR_RXBITCTR_PERIOD        UARTR_RXBITCTR_PERIOD_REG
    #define UARTR_RXBITCTR_CONTROL       UARTR_RXBITCTR_CONTROL_REG
    #define UARTR_RXBITCTR_COUNTER       UARTR_RXBITCTR_COUNTER_REG
    #define UARTR_RXSTATUS               UARTR_RXSTATUS_REG
    #define UARTR_RXSTATUS_MASK          UARTR_RXSTATUS_MASK_REG
    #define UARTR_RXSTATUS_ACTL          UARTR_RXSTATUS_ACTL_REG
#endif /* End  (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) */

#if(UARTR_INTERNAL_CLOCK_USED)
    #define UARTR_INTCLOCK_CLKEN         UARTR_INTCLOCK_CLKEN_REG
#endif /* End UARTR_INTERNAL_CLOCK_USED */

#define UARTR_WAIT_FOR_COMLETE_REINIT    UARTR_WAIT_FOR_COMPLETE_REINIT

#endif  /* CY_UART_UARTR_H */


/* [] END OF FILE */
