/*******************************************************************************
* File Name: UARTR_IntClock.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_UARTR_IntClock_H)
#define CY_CLOCK_UARTR_IntClock_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void UARTR_IntClock_Start(void) ;
void UARTR_IntClock_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void UARTR_IntClock_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void UARTR_IntClock_StandbyPower(uint8 state) ;
void UARTR_IntClock_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 UARTR_IntClock_GetDividerRegister(void) ;
void UARTR_IntClock_SetModeRegister(uint8 modeBitMask) ;
void UARTR_IntClock_ClearModeRegister(uint8 modeBitMask) ;
uint8 UARTR_IntClock_GetModeRegister(void) ;
void UARTR_IntClock_SetSourceRegister(uint8 clkSource) ;
uint8 UARTR_IntClock_GetSourceRegister(void) ;
#if defined(UARTR_IntClock__CFG3)
void UARTR_IntClock_SetPhaseRegister(uint8 clkPhase) ;
uint8 UARTR_IntClock_GetPhaseRegister(void) ;
#endif /* defined(UARTR_IntClock__CFG3) */

#define UARTR_IntClock_Enable()                       UARTR_IntClock_Start()
#define UARTR_IntClock_Disable()                      UARTR_IntClock_Stop()
#define UARTR_IntClock_SetDivider(clkDivider)         UARTR_IntClock_SetDividerRegister(clkDivider, 1u)
#define UARTR_IntClock_SetDividerValue(clkDivider)    UARTR_IntClock_SetDividerRegister((clkDivider) - 1u, 1u)
#define UARTR_IntClock_SetMode(clkMode)               UARTR_IntClock_SetModeRegister(clkMode)
#define UARTR_IntClock_SetSource(clkSource)           UARTR_IntClock_SetSourceRegister(clkSource)
#if defined(UARTR_IntClock__CFG3)
#define UARTR_IntClock_SetPhase(clkPhase)             UARTR_IntClock_SetPhaseRegister(clkPhase)
#define UARTR_IntClock_SetPhaseValue(clkPhase)        UARTR_IntClock_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(UARTR_IntClock__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define UARTR_IntClock_CLKEN              (* (reg8 *) UARTR_IntClock__PM_ACT_CFG)
#define UARTR_IntClock_CLKEN_PTR          ((reg8 *) UARTR_IntClock__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define UARTR_IntClock_CLKSTBY            (* (reg8 *) UARTR_IntClock__PM_STBY_CFG)
#define UARTR_IntClock_CLKSTBY_PTR        ((reg8 *) UARTR_IntClock__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define UARTR_IntClock_DIV_LSB            (* (reg8 *) UARTR_IntClock__CFG0)
#define UARTR_IntClock_DIV_LSB_PTR        ((reg8 *) UARTR_IntClock__CFG0)
#define UARTR_IntClock_DIV_PTR            ((reg16 *) UARTR_IntClock__CFG0)

/* Clock MSB divider configuration register. */
#define UARTR_IntClock_DIV_MSB            (* (reg8 *) UARTR_IntClock__CFG1)
#define UARTR_IntClock_DIV_MSB_PTR        ((reg8 *) UARTR_IntClock__CFG1)

/* Mode and source configuration register */
#define UARTR_IntClock_MOD_SRC            (* (reg8 *) UARTR_IntClock__CFG2)
#define UARTR_IntClock_MOD_SRC_PTR        ((reg8 *) UARTR_IntClock__CFG2)

#if defined(UARTR_IntClock__CFG3)
/* Analog clock phase configuration register */
#define UARTR_IntClock_PHASE              (* (reg8 *) UARTR_IntClock__CFG3)
#define UARTR_IntClock_PHASE_PTR          ((reg8 *) UARTR_IntClock__CFG3)
#endif /* defined(UARTR_IntClock__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define UARTR_IntClock_CLKEN_MASK         UARTR_IntClock__PM_ACT_MSK
#define UARTR_IntClock_CLKSTBY_MASK       UARTR_IntClock__PM_STBY_MSK

/* CFG2 field masks */
#define UARTR_IntClock_SRC_SEL_MSK        UARTR_IntClock__CFG2_SRC_SEL_MASK
#define UARTR_IntClock_MODE_MASK          (~(UARTR_IntClock_SRC_SEL_MSK))

#if defined(UARTR_IntClock__CFG3)
/* CFG3 phase mask */
#define UARTR_IntClock_PHASE_MASK         UARTR_IntClock__CFG3_PHASE_DLY_MASK
#endif /* defined(UARTR_IntClock__CFG3) */

#endif /* CY_CLOCK_UARTR_IntClock_H */


/* [] END OF FILE */
