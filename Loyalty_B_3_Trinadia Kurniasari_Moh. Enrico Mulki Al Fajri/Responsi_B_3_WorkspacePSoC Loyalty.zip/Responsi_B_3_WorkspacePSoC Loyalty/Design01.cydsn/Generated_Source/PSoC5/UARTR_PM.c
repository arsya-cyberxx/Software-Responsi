/*******************************************************************************
* File Name: UARTR_PM.c
* Version 2.50
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "UARTR.h"


/***************************************
* Local data allocation
***************************************/

static UARTR_BACKUP_STRUCT  UARTR_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: UARTR_SaveConfig
********************************************************************************
*
* Summary:
*  This function saves the component nonretention control register.
*  Does not save the FIFO which is a set of nonretention registers.
*  This function is called by the UARTR_Sleep() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UARTR_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UARTR_SaveConfig(void)
{
    #if(UARTR_CONTROL_REG_REMOVED == 0u)
        UARTR_backup.cr = UARTR_CONTROL_REG;
    #endif /* End UARTR_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: UARTR_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the nonretention control register except FIFO.
*  Does not restore the FIFO which is a set of nonretention registers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UARTR_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
* Notes:
*  If this function is called without calling UARTR_SaveConfig() 
*  first, the data loaded may be incorrect.
*
*******************************************************************************/
void UARTR_RestoreConfig(void)
{
    #if(UARTR_CONTROL_REG_REMOVED == 0u)
        UARTR_CONTROL_REG = UARTR_backup.cr;
    #endif /* End UARTR_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: UARTR_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred API to prepare the component for sleep. 
*  The UARTR_Sleep() API saves the current component state. Then it
*  calls the UARTR_Stop() function and calls 
*  UARTR_SaveConfig() to save the hardware configuration.
*  Call the UARTR_Sleep() function before calling the CyPmSleep() 
*  or the CyPmHibernate() function. 
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UARTR_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UARTR_Sleep(void)
{
    #if(UARTR_RX_ENABLED || UARTR_HD_ENABLED)
        if((UARTR_RXSTATUS_ACTL_REG  & UARTR_INT_ENABLE) != 0u)
        {
            UARTR_backup.enableState = 1u;
        }
        else
        {
            UARTR_backup.enableState = 0u;
        }
    #else
        if((UARTR_TXSTATUS_ACTL_REG  & UARTR_INT_ENABLE) !=0u)
        {
            UARTR_backup.enableState = 1u;
        }
        else
        {
            UARTR_backup.enableState = 0u;
        }
    #endif /* End UARTR_RX_ENABLED || UARTR_HD_ENABLED*/

    UARTR_Stop();
    UARTR_SaveConfig();
}


/*******************************************************************************
* Function Name: UARTR_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred API to restore the component to the state when 
*  UARTR_Sleep() was called. The UARTR_Wakeup() function
*  calls the UARTR_RestoreConfig() function to restore the 
*  configuration. If the component was enabled before the 
*  UARTR_Sleep() function was called, the UARTR_Wakeup()
*  function will also re-enable the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UARTR_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UARTR_Wakeup(void)
{
    UARTR_RestoreConfig();
    #if( (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) )
        UARTR_ClearRxBuffer();
    #endif /* End (UARTR_RX_ENABLED) || (UARTR_HD_ENABLED) */
    #if(UARTR_TX_ENABLED || UARTR_HD_ENABLED)
        UARTR_ClearTxBuffer();
    #endif /* End UARTR_TX_ENABLED || UARTR_HD_ENABLED */

    if(UARTR_backup.enableState != 0u)
    {
        UARTR_Enable();
    }
}


/* [] END OF FILE */
