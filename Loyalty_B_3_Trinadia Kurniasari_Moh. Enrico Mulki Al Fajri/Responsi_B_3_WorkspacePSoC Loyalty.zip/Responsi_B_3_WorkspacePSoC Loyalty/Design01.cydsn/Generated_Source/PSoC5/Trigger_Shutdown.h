/*******************************************************************************
* File Name: Trigger_Shutdown.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Trigger_Shutdown_H) /* Pins Trigger_Shutdown_H */
#define CY_PINS_Trigger_Shutdown_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Trigger_Shutdown_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_0 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Trigger_Shutdown__PORT == 15 && ((Trigger_Shutdown__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    Trigger_Shutdown_Write(uint8 value) ;
void    Trigger_Shutdown_SetDriveMode(uint8 mode) ;
uint8   Trigger_Shutdown_ReadDataReg(void) ;
uint8   Trigger_Shutdown_Read(void) ;
uint8   Trigger_Shutdown_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Trigger_Shutdown_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Trigger_Shutdown_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Trigger_Shutdown_DM_RES_UP          PIN_DM_RES_UP
#define Trigger_Shutdown_DM_RES_DWN         PIN_DM_RES_DWN
#define Trigger_Shutdown_DM_OD_LO           PIN_DM_OD_LO
#define Trigger_Shutdown_DM_OD_HI           PIN_DM_OD_HI
#define Trigger_Shutdown_DM_STRONG          PIN_DM_STRONG
#define Trigger_Shutdown_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Trigger_Shutdown_MASK               Trigger_Shutdown__MASK
#define Trigger_Shutdown_SHIFT              Trigger_Shutdown__SHIFT
#define Trigger_Shutdown_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Trigger_Shutdown_PS                     (* (reg8 *) Trigger_Shutdown__PS)
/* Data Register */
#define Trigger_Shutdown_DR                     (* (reg8 *) Trigger_Shutdown__DR)
/* Port Number */
#define Trigger_Shutdown_PRT_NUM                (* (reg8 *) Trigger_Shutdown__PRT) 
/* Connect to Analog Globals */                                                  
#define Trigger_Shutdown_AG                     (* (reg8 *) Trigger_Shutdown__AG)                       
/* Analog MUX bux enable */
#define Trigger_Shutdown_AMUX                   (* (reg8 *) Trigger_Shutdown__AMUX) 
/* Bidirectional Enable */                                                        
#define Trigger_Shutdown_BIE                    (* (reg8 *) Trigger_Shutdown__BIE)
/* Bit-mask for Aliased Register Access */
#define Trigger_Shutdown_BIT_MASK               (* (reg8 *) Trigger_Shutdown__BIT_MASK)
/* Bypass Enable */
#define Trigger_Shutdown_BYP                    (* (reg8 *) Trigger_Shutdown__BYP)
/* Port wide control signals */                                                   
#define Trigger_Shutdown_CTL                    (* (reg8 *) Trigger_Shutdown__CTL)
/* Drive Modes */
#define Trigger_Shutdown_DM0                    (* (reg8 *) Trigger_Shutdown__DM0) 
#define Trigger_Shutdown_DM1                    (* (reg8 *) Trigger_Shutdown__DM1)
#define Trigger_Shutdown_DM2                    (* (reg8 *) Trigger_Shutdown__DM2) 
/* Input Buffer Disable Override */
#define Trigger_Shutdown_INP_DIS                (* (reg8 *) Trigger_Shutdown__INP_DIS)
/* LCD Common or Segment Drive */
#define Trigger_Shutdown_LCD_COM_SEG            (* (reg8 *) Trigger_Shutdown__LCD_COM_SEG)
/* Enable Segment LCD */
#define Trigger_Shutdown_LCD_EN                 (* (reg8 *) Trigger_Shutdown__LCD_EN)
/* Slew Rate Control */
#define Trigger_Shutdown_SLW                    (* (reg8 *) Trigger_Shutdown__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Trigger_Shutdown_PRTDSI__CAPS_SEL       (* (reg8 *) Trigger_Shutdown__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Trigger_Shutdown_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Trigger_Shutdown__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Trigger_Shutdown_PRTDSI__OE_SEL0        (* (reg8 *) Trigger_Shutdown__PRTDSI__OE_SEL0) 
#define Trigger_Shutdown_PRTDSI__OE_SEL1        (* (reg8 *) Trigger_Shutdown__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Trigger_Shutdown_PRTDSI__OUT_SEL0       (* (reg8 *) Trigger_Shutdown__PRTDSI__OUT_SEL0) 
#define Trigger_Shutdown_PRTDSI__OUT_SEL1       (* (reg8 *) Trigger_Shutdown__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Trigger_Shutdown_PRTDSI__SYNC_OUT       (* (reg8 *) Trigger_Shutdown__PRTDSI__SYNC_OUT) 


#if defined(Trigger_Shutdown__INTSTAT)  /* Interrupt Registers */

    #define Trigger_Shutdown_INTSTAT                (* (reg8 *) Trigger_Shutdown__INTSTAT)
    #define Trigger_Shutdown_SNAP                   (* (reg8 *) Trigger_Shutdown__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Trigger_Shutdown_H */


/* [] END OF FILE */
