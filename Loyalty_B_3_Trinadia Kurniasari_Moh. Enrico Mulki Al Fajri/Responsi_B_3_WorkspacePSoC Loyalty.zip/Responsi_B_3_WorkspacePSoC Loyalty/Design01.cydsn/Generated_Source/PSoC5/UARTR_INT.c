/*******************************************************************************
* File Name: UARTRINT.c
* Version 2.50
*
* Description:
*  This file provides all Interrupt Service functionality of the UART component
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "UARTR.h"
#include "cyapicallbacks.h"


/***************************************
* Custom Declarations
***************************************/
/* `#START CUSTOM_DECLARATIONS` Place your declaration here */

/* `#END` */

#if (UARTR_RX_INTERRUPT_ENABLED && (UARTR_RX_ENABLED || UARTR_HD_ENABLED))
    /*******************************************************************************
    * Function Name: UARTR_RXISR
    ********************************************************************************
    *
    * Summary:
    *  Interrupt Service Routine for RX portion of the UART
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTR_rxBuffer - RAM buffer pointer for save received data.
    *  UARTR_rxBufferWrite - cyclic index for write to rxBuffer,
    *     increments after each byte saved to buffer.
    *  UARTR_rxBufferRead - cyclic index for read from rxBuffer,
    *     checked to detect overflow condition.
    *  UARTR_rxBufferOverflow - software overflow flag. Set to one
    *     when UARTR_rxBufferWrite index overtakes
    *     UARTR_rxBufferRead index.
    *  UARTR_rxBufferLoopDetect - additional variable to detect overflow.
    *     Set to one when UARTR_rxBufferWrite is equal to
    *    UARTR_rxBufferRead
    *  UARTR_rxAddressMode - this variable contains the Address mode,
    *     selected in customizer or set by UART_SetRxAddressMode() API.
    *  UARTR_rxAddressDetected - set to 1 when correct address received,
    *     and analysed to store following addressed data bytes to the buffer.
    *     When not correct address received, set to 0 to skip following data bytes.
    *
    *******************************************************************************/
    CY_ISR(UARTR_RXISR)
    {
        uint8 readData;
        uint8 readStatus;
        uint8 increment_pointer = 0u;

    #if(CY_PSOC3)
        uint8 int_en;
    #endif /* (CY_PSOC3) */

    #ifdef UARTR_RXISR_ENTRY_CALLBACK
        UARTR_RXISR_EntryCallback();
    #endif /* UARTR_RXISR_ENTRY_CALLBACK */

        /* User code required at start of ISR */
        /* `#START UARTR_RXISR_START` */

        /* `#END` */

    #if(CY_PSOC3)   /* Make sure nested interrupt is enabled */
        int_en = EA;
        CyGlobalIntEnable;
    #endif /* (CY_PSOC3) */

        do
        {
            /* Read receiver status register */
            readStatus = UARTR_RXSTATUS_REG;
            /* Copy the same status to readData variable for backward compatibility support 
            *  of the user code in UARTR_RXISR_ERROR` section. 
            */
            readData = readStatus;

            if((readStatus & (UARTR_RX_STS_BREAK | 
                            UARTR_RX_STS_PAR_ERROR |
                            UARTR_RX_STS_STOP_ERROR | 
                            UARTR_RX_STS_OVERRUN)) != 0u)
            {
                /* ERROR handling. */
                UARTR_errorStatus |= readStatus & ( UARTR_RX_STS_BREAK | 
                                                            UARTR_RX_STS_PAR_ERROR | 
                                                            UARTR_RX_STS_STOP_ERROR | 
                                                            UARTR_RX_STS_OVERRUN);
                /* `#START UARTR_RXISR_ERROR` */

                /* `#END` */
                
            #ifdef UARTR_RXISR_ERROR_CALLBACK
                UARTR_RXISR_ERROR_Callback();
            #endif /* UARTR_RXISR_ERROR_CALLBACK */
            }
            
            if((readStatus & UARTR_RX_STS_FIFO_NOTEMPTY) != 0u)
            {
                /* Read data from the RX data register */
                readData = UARTR_RXDATA_REG;
            #if (UARTR_RXHW_ADDRESS_ENABLED)
                if(UARTR_rxAddressMode == (uint8)UARTR__B_UART__AM_SW_DETECT_TO_BUFFER)
                {
                    if((readStatus & UARTR_RX_STS_MRKSPC) != 0u)
                    {
                        if ((readStatus & UARTR_RX_STS_ADDR_MATCH) != 0u)
                        {
                            UARTR_rxAddressDetected = 1u;
                        }
                        else
                        {
                            UARTR_rxAddressDetected = 0u;
                        }
                    }
                    if(UARTR_rxAddressDetected != 0u)
                    {   /* Store only addressed data */
                        UARTR_rxBuffer[UARTR_rxBufferWrite] = readData;
                        increment_pointer = 1u;
                    }
                }
                else /* Without software addressing */
                {
                    UARTR_rxBuffer[UARTR_rxBufferWrite] = readData;
                    increment_pointer = 1u;
                }
            #else  /* Without addressing */
                UARTR_rxBuffer[UARTR_rxBufferWrite] = readData;
                increment_pointer = 1u;
            #endif /* (UARTR_RXHW_ADDRESS_ENABLED) */

                /* Do not increment buffer pointer when skip not addressed data */
                if(increment_pointer != 0u)
                {
                    if(UARTR_rxBufferLoopDetect != 0u)
                    {   /* Set Software Buffer status Overflow */
                        UARTR_rxBufferOverflow = 1u;
                    }
                    /* Set next pointer. */
                    UARTR_rxBufferWrite++;

                    /* Check pointer for a loop condition */
                    if(UARTR_rxBufferWrite >= UARTR_RX_BUFFER_SIZE)
                    {
                        UARTR_rxBufferWrite = 0u;
                    }

                    /* Detect pre-overload condition and set flag */
                    if(UARTR_rxBufferWrite == UARTR_rxBufferRead)
                    {
                        UARTR_rxBufferLoopDetect = 1u;
                        /* When Hardware Flow Control selected */
                        #if (UARTR_FLOW_CONTROL != 0u)
                            /* Disable RX interrupt mask, it is enabled when user read data from the buffer using APIs */
                            UARTR_RXSTATUS_MASK_REG  &= (uint8)~UARTR_RX_STS_FIFO_NOTEMPTY;
                            CyIntClearPending(UARTR_RX_VECT_NUM);
                            break; /* Break the reading of the FIFO loop, leave the data there for generating RTS signal */
                        #endif /* (UARTR_FLOW_CONTROL != 0u) */
                    }
                }
            }
        }while((readStatus & UARTR_RX_STS_FIFO_NOTEMPTY) != 0u);

        /* User code required at end of ISR (Optional) */
        /* `#START UARTR_RXISR_END` */

        /* `#END` */

    #ifdef UARTR_RXISR_EXIT_CALLBACK
        UARTR_RXISR_ExitCallback();
    #endif /* UARTR_RXISR_EXIT_CALLBACK */

    #if(CY_PSOC3)
        EA = int_en;
    #endif /* (CY_PSOC3) */
    }
    
#endif /* (UARTR_RX_INTERRUPT_ENABLED && (UARTR_RX_ENABLED || UARTR_HD_ENABLED)) */


#if (UARTR_TX_INTERRUPT_ENABLED && UARTR_TX_ENABLED)
    /*******************************************************************************
    * Function Name: UARTR_TXISR
    ********************************************************************************
    *
    * Summary:
    * Interrupt Service Routine for the TX portion of the UART
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  UARTR_txBuffer - RAM buffer pointer for transmit data from.
    *  UARTR_txBufferRead - cyclic index for read and transmit data
    *     from txBuffer, increments after each transmitted byte.
    *  UARTR_rxBufferWrite - cyclic index for write to txBuffer,
    *     checked to detect available for transmission bytes.
    *
    *******************************************************************************/
    CY_ISR(UARTR_TXISR)
    {
    #if(CY_PSOC3)
        uint8 int_en;
    #endif /* (CY_PSOC3) */

    #ifdef UARTR_TXISR_ENTRY_CALLBACK
        UARTR_TXISR_EntryCallback();
    #endif /* UARTR_TXISR_ENTRY_CALLBACK */

        /* User code required at start of ISR */
        /* `#START UARTR_TXISR_START` */

        /* `#END` */

    #if(CY_PSOC3)   /* Make sure nested interrupt is enabled */
        int_en = EA;
        CyGlobalIntEnable;
    #endif /* (CY_PSOC3) */

        while((UARTR_txBufferRead != UARTR_txBufferWrite) &&
             ((UARTR_TXSTATUS_REG & UARTR_TX_STS_FIFO_FULL) == 0u))
        {
            /* Check pointer wrap around */
            if(UARTR_txBufferRead >= UARTR_TX_BUFFER_SIZE)
            {
                UARTR_txBufferRead = 0u;
            }

            UARTR_TXDATA_REG = UARTR_txBuffer[UARTR_txBufferRead];

            /* Set next pointer */
            UARTR_txBufferRead++;
        }

        /* User code required at end of ISR (Optional) */
        /* `#START UARTR_TXISR_END` */

        /* `#END` */

    #ifdef UARTR_TXISR_EXIT_CALLBACK
        UARTR_TXISR_ExitCallback();
    #endif /* UARTR_TXISR_EXIT_CALLBACK */

    #if(CY_PSOC3)
        EA = int_en;
    #endif /* (CY_PSOC3) */
   }
#endif /* (UARTR_TX_INTERRUPT_ENABLED && UARTR_TX_ENABLED) */


/* [] END OF FILE */
